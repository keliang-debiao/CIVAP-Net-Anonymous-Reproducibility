# Local data directory

Source data are intentionally absent. Place public repository files under `data/raw/` according to `configs/datasets.yaml`. Derived harmonized tables are written to `data/processed/` and are excluded from the archive by `.gitignore`.
