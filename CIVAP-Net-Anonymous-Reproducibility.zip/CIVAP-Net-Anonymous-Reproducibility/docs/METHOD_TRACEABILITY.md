# Method-to-code traceability

| Manuscript component | Code location | Primary artifact |
|---|---|---|
| Cross-survey harmonization | `src/civap_net/harmonize.py` | `outputs/audit/*.json`, harmonized CSV files |
| Five-fold outer partition | `src/civap_net/splits.py` | `outputs/folds/outer_folds.csv` |
| Fold-local preprocessing | `src/civap_net/preprocessing.py` | fold-specific JSON state |
| Missing-aware profile encoder | `src/civap_net/model.py` | checkpoint state |
| Low-rank exposure interaction | `src/civap_net/model.py` | checkpoint state |
| Label-safe retrieval | `src/civap_net/retrieval.py` | fold-specific bank files |
| Shrunk country residual | `src/civap_net/model.py` | checkpoint state and country counts |
| Auxiliary and country-risk losses | `src/civap_net/losses.py` | training logs |
| Temperature and threshold | `src/civap_net/calibration.py` | fold post-processing JSON |
| Metrics and calibration | `src/civap_net/metrics.py` | result CSV and JSON files |
| Country-cluster inference | `src/civap_net/bootstrap.py` | bootstrap contrast CSV |
| Robustness | `src/civap_net/robustness.py` | robustness CSV |
| Grouped permutation sensitivity | `src/civap_net/interpretability.py` | importance CSV |
| Figures 3–8 | `scripts/10_make_figures.py` | `outputs/figures/*.png` |
