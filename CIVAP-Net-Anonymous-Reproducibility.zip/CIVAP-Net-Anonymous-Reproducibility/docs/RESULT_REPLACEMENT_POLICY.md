# Result provenance policy

Files under `logs/reference_targets/` are manuscript-derived targets for reproduction guidance. Each file carries `record_type=reference_target` or an equivalent metadata field. They are not execution records and must not be represented as training provenance.

Actual commands write records under `outputs/logs/`. A completed execution record must include:

- UTC timestamp;
- command and seed;
- configuration SHA-256 digest;
- source-file SHA-256 digests;
- Python, PyTorch, CUDA, scikit-learn, FAISS, XGBoost, and LightGBM versions when installed;
- exit status;
- generated artifact paths.

For repository submission, preserve the distinction between target records and execution records. If actual run outputs are published, the manuscript must be checked against those outputs rather than against the target files.
