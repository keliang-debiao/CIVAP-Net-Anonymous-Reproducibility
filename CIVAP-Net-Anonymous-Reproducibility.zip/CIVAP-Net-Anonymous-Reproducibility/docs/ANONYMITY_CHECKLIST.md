# Anonymous repository checklist

- No author name, email address, affiliation, ORCID, account handle, local home path, or institution-specific server path.
- No source survey redistribution.
- No Git history carrying personal identity.
- No notebook metadata carrying usernames or local paths.
- No credential, token, cookie, private key, or signed download URL.
- No external outcomes used for fitting, model selection, calibration, thresholding, or checkpoint choice.
- Reference target records remain explicitly distinguished from machine execution records.
- `python scripts/00_validate_package.py` completes before archive creation.
