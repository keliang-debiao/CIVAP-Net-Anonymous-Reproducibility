# Reproduction runbook

1. Create the environment from `environment.yml` or `requirements.txt`.
2. Place the public source files at the paths listed in `configs/datasets.yaml`.
3. Run the package validator.
4. Audit and harmonize both cohorts.
5. Generate the fixed outer and inner fold definitions.
6. Fit CIVAP-Net under the five outer folds. Each epoch rebuilds a training-only retrieval index and excludes the query identifier.
7. Generate three-fold inner out-of-fold logits inside each outer-training partition. Fit temperature by Bernoulli negative log likelihood and select the F1-maximizing threshold, resolving ties by proximity to 0.50.
8. Fit all baselines on the same harmonized matrix and fixed folds. TabICL and TabICLv2 use the official package and named checkpoints in `manifests/foundation_models.json`.
9. Freeze all development-derived objects and score the external cohort without fine-tuning, threshold adjustment, or recalibration.
10. Run ablation, calibration, robustness, statistical, interpretation, and efficiency commands.
11. Generate tables and figures from machine outputs.
12. Compare machine outputs with `logs/reference_targets/` and investigate any discrepancy before manuscript use.

Every command writes a JSON run record containing the command name, UTC time, seed, configuration digest, environment versions, input digests, output paths, and completion status.
