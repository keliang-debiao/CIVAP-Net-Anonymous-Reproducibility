# Data access and local placement

## Development cohort

- Source: International Climate Psychology Collaboration public OSF release.
- Project page: https://osf.io/ytf89/
- Required local files:
  - `data/raw/icpc/data_notimers.csv`
  - `data/raw/icpc/codebook.xlsx`

## External cohort

- Source: openICPSR project 208254, version V1.
- Project DOI: https://doi.org/10.3886/E208254V1
- Required local files:
  - `data/raw/external/data/all.dta`
  - `data/raw/external/data/codebook.csv`

The archive does not copy source data. Access conditions and licensing remain governed by the two public repositories. The analysis code retains only derived fold identifiers, metrics, and model artifacts under `outputs/`.
