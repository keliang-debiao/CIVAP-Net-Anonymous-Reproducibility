from __future__ import annotations
import numpy as np
from sklearn.metrics import roc_auc_score,average_precision_score,f1_score,brier_score_loss
from sklearn.linear_model import LogisticRegression

def expected_calibration_error(y,p,bins=10):
    y=np.asarray(y,dtype=float); p=np.asarray(p,dtype=float)
    order=np.argsort(p,kind="mergesort"); groups=np.array_split(order,bins); total=len(y); ece=0.0
    for idx in groups:
        if len(idx): ece += len(idx)/total*abs(float(y[idx].mean()-p[idx].mean()))
    return float(ece)

def calibration_intercept_slope(y,p):
    eps=1e-7; p=np.clip(np.asarray(p,dtype=float),eps,1-eps); logit=np.log(p/(1-p)).reshape(-1,1)
    model=LogisticRegression(C=1e6,solver="lbfgs",max_iter=2000).fit(logit,np.asarray(y,dtype=int))
    return float(model.intercept_[0]),float(model.coef_[0,0])

def binary_metrics(y,p,threshold=0.5):
    y=np.asarray(y,dtype=int); p=np.asarray(p,dtype=float); pred=(p>=threshold).astype(int)
    intercept,slope=calibration_intercept_slope(y,p)
    return {"auroc":float(roc_auc_score(y,p)),"auprc":float(average_precision_score(y,p)),"f1":float(f1_score(y,pred,zero_division=0)),"brier":float(brier_score_loss(y,p)),"ece":expected_calibration_error(y,p),"calibration_intercept":intercept,"calibration_slope":slope}

def mean_sd_ci(values,confidence=0.95):
    from scipy.stats import t
    x=np.asarray(values,dtype=float); mean=float(x.mean()); sd=float(x.std(ddof=1)); half=float(t.ppf((1+confidence)/2,len(x)-1)*sd/np.sqrt(len(x)))
    return {"mean":mean,"sd":sd,"ci_low":mean-half,"ci_high":mean+half}
