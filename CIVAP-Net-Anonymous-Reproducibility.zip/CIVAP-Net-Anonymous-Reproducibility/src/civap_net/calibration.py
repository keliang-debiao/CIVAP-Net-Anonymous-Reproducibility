from __future__ import annotations
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import expit
from sklearn.metrics import f1_score,log_loss

def fit_temperature(logits,y):
    x=np.asarray(logits,dtype=float); target=np.asarray(y,dtype=int)
    objective=lambda log_t: log_loss(target,expit(x/np.exp(log_t)),labels=[0,1])
    result=minimize_scalar(objective,bounds=(np.log(0.05),np.log(20.0)),method="bounded",options={"xatol":1e-8,"maxiter":200})
    if not result.success: raise RuntimeError(f"Temperature optimization failed: {result.message}")
    return float(np.exp(result.x))

def apply_temperature(logits,temperature):
    z=np.asarray(logits,dtype=float)/float(temperature)
    return 1.0/(1.0+np.exp(-np.clip(z,-50,50)))

def select_f1_threshold(y,probabilities):
    y=np.asarray(y,dtype=int); p=np.asarray(probabilities,dtype=float)
    candidates=np.unique(np.concatenate(([0.0,0.5,1.0],p)))
    scores=np.asarray([f1_score(y,p>=t,zero_division=0) for t in candidates])
    best=np.flatnonzero(np.isclose(scores,scores.max(),rtol=0,atol=1e-12))
    return float(candidates[best[np.argmin(np.abs(candidates[best]-0.5))]])
