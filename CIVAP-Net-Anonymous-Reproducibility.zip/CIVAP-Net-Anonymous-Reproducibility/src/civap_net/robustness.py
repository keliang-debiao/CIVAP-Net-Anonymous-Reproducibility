from __future__ import annotations
from dataclasses import replace
import numpy as np
from .preprocessing import EncodedFrame

def additional_missingness(data:EncodedFrame,rate:float,seed:int):
    rng=np.random.default_rng(seed); n=len(data); result=replace(data,**{k:getattr(data,k).copy() for k in data.__dataclass_fields__})
    mask=rng.random((n,3))<rate
    result.age=np.where(mask[:,0],0.0,result.age); result.age_observed=np.where(mask[:,0],0.0,result.age_observed)
    result.gender=np.where(mask[:,1],1,result.gender); result.education=np.where(mask[:,2],1,result.education)
    return result

def perturb_age(data:EncodedFrame,years:float,age_std:float,seed:int):
    rng=np.random.default_rng(seed); result=replace(data,**{k:getattr(data,k).copy() for k in data.__dataclass_fields__})
    noise=rng.uniform(-years,years,size=len(data))/max(age_std,1e-8); result.age=result.age+noise.astype(np.float32)*result.age_observed
    return result
