from __future__ import annotations
import torch
import torch.nn.functional as F

def masked_smooth_l1(pred,target,mask,beta=0.10):
    if mask.sum() == 0:
        return pred.new_tensor(0.0)
    loss=F.smooth_l1_loss(pred,target,reduction="none",beta=beta)
    return (loss*mask).sum()/mask.sum()

def country_risk_penalty(logits,y,country_ids,country_train_count,minimum_count=100):
    per=F.binary_cross_entropy_with_logits(logits,y,reduction="none")
    overall=per.mean(); terms=[]; weights=[]
    for country in torch.unique(country_ids):
        mask=country_ids.eq(country)
        if int(country_train_count[country]) >= minimum_count and int(mask.sum()) > 0:
            terms.append((per[mask].mean()-overall).pow(2)); weights.append(mask.sum().float())
    if not terms:
        return logits.new_tensor(0.0)
    w=torch.stack(weights); w=w/w.sum()
    return (torch.stack(terms)*w).sum()

def total_loss(outputs,batch,model,cfg):
    bce=F.binary_cross_entropy_with_logits(outputs["logit"],batch["y"])
    aux=masked_smooth_l1(outputs["auxiliary"],batch["auxiliary"],batch["auxiliary_mask"],float(cfg["smooth_l1_delta"])) if model.cfg["modules"]["auxiliary_loss"] else bce.new_tensor(0.0)
    group=country_risk_penalty(outputs["logit"],batch["y"],batch["country"],model.country_train_count,int(cfg["minimum_country_records_for_group_loss"])) if model.cfg["modules"]["country_risk_penalty"] else bce.new_tensor(0.0)
    emb=model.country_emb.weight.pow(2).sum()
    total=bce+float(cfg["lambda_auxiliary"])*aux+float(cfg["lambda_group"])*group+float(cfg["lambda_country_embedding"])*emb
    return total,{"bce":float(bce.detach()),"auxiliary":float(aux.detach()),"group":float(group.detach()),"embedding":float(emb.detach())}
