from __future__ import annotations
from pathlib import Path
import json
import pandas as pd

def ensure_dirs():
    for path in ["data/processed","outputs/audit","outputs/folds","outputs/checkpoints","outputs/predictions","outputs/retrieval_banks","outputs/metrics","outputs/logs","outputs/figures"]:
        Path(path).mkdir(parents=True,exist_ok=True)

def write_json(path,obj):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(obj,indent=2,sort_keys=True),encoding="utf-8")

def read_table(path):
    path=Path(path)
    if path.suffix.lower()==".csv": return pd.read_csv(path)
    if path.suffix.lower()==".dta": return pd.read_stata(path)
    raise ValueError(f"Unsupported table: {path}")
