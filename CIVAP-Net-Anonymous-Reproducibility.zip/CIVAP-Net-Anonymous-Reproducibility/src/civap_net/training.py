from __future__ import annotations
from copy import deepcopy
import math
import numpy as np
import torch
from torch.optim import AdamW
from sklearn.metrics import roc_auc_score,brier_score_loss
from .preprocessing import tensor_batch,EncodedFrame
from .losses import total_loss

def set_seed(seed):
    import random
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

def _all_batch(data,device):
    return tensor_batch(data,np.arange(len(data)),device)

def predict_logits(model,data,bank,device,batch_size=2048):
    model.eval(); logits=[]
    with torch.no_grad():
        for start in range(0,len(data),batch_size):
            idx=np.arange(start,min(start+batch_size,len(data)))
            out=model(tensor_batch(data,idx,device),bank)
            logits.append(out["logit"].detach().cpu().numpy())
    return np.concatenate(logits)

def fit_model(model,train:EncodedFrame,valid:EncodedFrame,cfg:dict,device,seed=2026):
    set_seed(seed); model.to(device)
    optimizer=AdamW(model.parameters(),lr=float(cfg["learning_rate"]),weight_decay=float(cfg["weight_decay"]))
    max_epochs=int(cfg["max_epochs"]); warmup=int(cfg["warmup_epochs"]); patience=int(cfg["early_stopping_patience"])
    best=None; best_auc=-np.inf; best_brier=np.inf; stale=0; history=[]
    for epoch in range(max_epochs):
        if epoch < warmup:
            factor=(epoch+1)/max(1,warmup)
        else:
            factor=0.5*(1+math.cos(math.pi*(epoch-warmup)/max(1,max_epochs-warmup)))
        for group in optimizer.param_groups: group["lr"]=float(cfg["learning_rate"])*factor
        full=_all_batch(train,device); bank=model.make_bank(full).to(device)
        model.train(); order=np.random.default_rng(seed+epoch).permutation(len(train)); epoch_loss=[]
        for start in range(0,len(train),int(cfg["batch_size"])):
            idx=order[start:start+int(cfg["batch_size"])]
            batch=tensor_batch(train,idx,device); optimizer.zero_grad(set_to_none=True)
            outputs=model(batch,bank); loss,parts=total_loss(outputs,batch,model,cfg); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),float(cfg["gradient_clip_norm"])); optimizer.step(); epoch_loss.append(float(loss.detach()))
        evaluation_bank=model.make_bank(_all_batch(train,device)).to(device)
        logits=predict_logits(model,valid,evaluation_bank,device); prob=1/(1+np.exp(-np.clip(logits,-50,50)))
        auc=float(roc_auc_score(valid.y,prob)); brier=float(brier_score_loss(valid.y,prob))
        history.append({"epoch":epoch+1,"loss":float(np.mean(epoch_loss)),"val_auroc":auc,"val_brier":brier})
        improved=(auc>best_auc+1e-8) or (abs(auc-best_auc)<=1e-8 and brier<best_brier)
        if improved:
            best_auc,best_brier=auc,brier; best=deepcopy(model.state_dict()); stale=0
        else:
            stale+=1
        if stale>=patience: break
    model.load_state_dict(best); final_bank=model.make_bank(_all_batch(train,device)).to(device)
    return model,final_bank,history
