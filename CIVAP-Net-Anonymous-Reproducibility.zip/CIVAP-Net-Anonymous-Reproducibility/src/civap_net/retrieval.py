from __future__ import annotations
from dataclasses import dataclass
import torch
import torch.nn.functional as F

@dataclass
class RetrievalBank:
    keys: torch.Tensor
    states: torch.Tensor
    labels: torch.Tensor
    row_ids: torch.Tensor

    def to(self, device):
        return RetrievalBank(*(x.to(device) for x in (self.keys, self.states, self.labels, self.row_ids)))

def retrieve(query_keys: torch.Tensor, query_ids: torch.Tensor, bank: RetrievalBank, k: int, tau: float):
    if len(bank.keys) <= k:
        raise ValueError("Retrieval bank must contain more rows than k")
    query_keys = F.normalize(query_keys, dim=-1)
    bank_keys = F.normalize(bank.keys, dim=-1)
    similarities = query_keys @ bank_keys.T
    same = query_ids[:, None].eq(bank.row_ids[None, :])
    similarities = similarities.masked_fill(same, float("-inf"))
    values, indices = torch.topk(similarities, k=k, dim=1)
    weights = torch.softmax(values / tau, dim=1)
    return indices, weights
