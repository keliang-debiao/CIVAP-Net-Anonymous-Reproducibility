from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold, StratifiedKFold

def make_outer_folds(frame: pd.DataFrame, n_splits: int = 5, seed: int = 2026) -> pd.DataFrame:
    splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    fold = np.full(len(frame), -1, dtype=int)
    y = frame["y"].astype(int).to_numpy()
    groups = frame["row_id"].astype(str).to_numpy()
    for k, (_, val_idx) in enumerate(splitter.split(np.zeros(len(frame)), y, groups), start=1):
        fold[val_idx] = k
    if np.any(fold < 1):
        raise RuntimeError("Outer fold assignment is incomplete")
    return pd.DataFrame({"row_id": frame["row_id"], "fold": fold, "y": y, "country": frame["country"]})

def make_inner_folds(frame: pd.DataFrame, n_splits: int = 3, seed: int = 2026) -> np.ndarray:
    splitter = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    result = np.full(len(frame), -1, dtype=int)
    y = frame["y"].astype(int).to_numpy()
    for k, (_, val_idx) in enumerate(splitter.split(np.zeros(len(frame)), y), start=1):
        result[val_idx] = k
    return result

def assert_partition(train_ids, test_ids) -> None:
    overlap = set(map(str, train_ids)).intersection(map(str, test_ids))
    if overlap:
        raise AssertionError(f"Entity overlap across partitions: {len(overlap)}")
