from __future__ import annotations
from dataclasses import replace
import numpy as np
from sklearn.metrics import roc_auc_score
from scipy.stats import rankdata

GROUP_FIELDS={"age":["age","age_observed"],"gender":["gender"],"education":["education"],"assigned_exposure":["exposure"],"country":["country","country_text"]}

def permute_group(data,group,seed):
    rng=np.random.default_rng(seed); perm=rng.permutation(len(data)); result=replace(data,**{k:getattr(data,k).copy() for k in data.__dataclass_fields__})
    for field in GROUP_FIELDS[group]: setattr(result,field,getattr(result,field)[perm])
    return result

def importance_drop(y,base_probability,permuted_probability):
    return float(roc_auc_score(y,base_probability)-roc_auc_score(y,permuted_probability))

def kendalls_w(rank_matrix):
    ranks=np.asarray(rank_matrix,dtype=float); m,n=ranks.shape; sums=ranks.sum(axis=0); s=((sums-sums.mean())**2).sum()
    return float(12*s/(m*m*(n**3-n)))
