from __future__ import annotations
from pathlib import Path
import hashlib
import numpy as np
import pandas as pd

AGE_BAND_MIDPOINTS = {
    "18–24": 21.0, "18-24": 21.0,
    "25–34": 30.0, "25-34": 30.0,
    "35–49": 42.0, "35-49": 42.0,
    "50–64": 57.0, "50-64": 57.0,
    "65+": 70.0,
}

def _stable_id(prefix: str, value: object, index: int) -> str:
    if pd.isna(value) or str(value).strip() == "":
        raw = f"{prefix}:row:{index}"
    else:
        raw = f"{prefix}:id:{str(value).strip()}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]

def _norm_text(value: object) -> str:
    if pd.isna(value):
        return "missing"
    return " ".join(str(value).strip().lower().split())

def _country(value: object) -> str:
    text = _norm_text(value)
    aliases = {
        "usa": "united states", "u.s.a.": "united states", "us": "united states",
        "uk": "united kingdom", "u.k.": "united kingdom",
        "south korea": "south korea", "republic of korea": "south korea",
    }
    return aliases.get(text, text)

def harmonize_development(frame: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    required = [cfg[k] for k in ["age", "gender", "education", "exposure", "country", "target"]]
    missing = [c for c in required if c not in frame.columns]
    if missing:
        raise KeyError(f"Missing development columns: {missing}")
    out = pd.DataFrame(index=frame.index)
    ids = frame[cfg["id"]] if cfg.get("id") in frame.columns else pd.Series(np.nan, index=frame.index)
    out["row_id"] = [_stable_id("dev", v, int(i)) for i, v in zip(frame.index, ids)]
    out["age"] = pd.to_numeric(frame[cfg["age"]], errors="coerce")
    gender_map = {"1": "male", "2": "female", "3": "other_or_undisclosed", "4": "other_or_undisclosed"}
    out["gender"] = frame[cfg["gender"]].map(lambda v: gender_map.get(_norm_text(v), "missing" if pd.isna(v) else "other_or_undisclosed"))
    education_map = {"1": "primary", "2": "secondary", "3": "tertiary", "4": "advanced", "5": "unknown"}
    out["education"] = frame[cfg["education"]].map(lambda v: education_map.get(_norm_text(v), "missing" if pd.isna(v) else "unknown"))
    cond = pd.to_numeric(frame[cfg["exposure"]], errors="coerce")
    out["exposure"] = np.where(cond.eq(1), "control", "exposed")
    out.loc[cond.isna(), "exposure"] = "missing"
    out["country"] = frame[cfg["country"]].map(_country)
    slider = pd.to_numeric(frame[cfg["target"]], errors="coerce")
    out["primary_slider"] = slider
    out["y"] = np.where(slider.notna(), (slider > 50).astype(float), np.nan)
    for idx, name in enumerate(cfg.get("auxiliary_targets", []), start=1):
        out[f"aux_{idx}"] = pd.to_numeric(frame[name], errors="coerce") / 100.0 if name in frame.columns else np.nan
    return out.loc[out["y"].notna()].reset_index(drop=True)

def harmonize_external(frame: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    required = [cfg[k] for k in ["age", "gender", "education", "treatment_climate", "treatment_policy", "country", "target"]]
    missing = [c for c in required if c not in frame.columns]
    if missing:
        raise KeyError(f"Missing external columns: {missing}")
    out = pd.DataFrame(index=frame.index)
    ids = frame[cfg["id"]] if cfg.get("id") in frame.columns else pd.Series(np.nan, index=frame.index)
    out["row_id"] = [_stable_id("ext", v, int(i)) for i, v in zip(frame.index, ids)]
    raw_age = frame[cfg["age"]]
    numeric = pd.to_numeric(raw_age, errors="coerce")
    mapped = raw_age.map(lambda v: AGE_BAND_MIDPOINTS.get(str(v).strip(), np.nan))
    out["age"] = numeric.where(numeric.notna(), mapped)
    out["gender"] = frame[cfg["gender"]].map(lambda v: {"female":"female","male":"male","other":"other_or_undisclosed"}.get(_norm_text(v), "missing" if pd.isna(v) else "other_or_undisclosed"))
    edu = {
        "none":"primary", "primary":"primary", "lower secondary":"secondary",
        "vocational":"secondary", "high school":"secondary", "college":"tertiary",
        "master":"advanced",
    }
    out["education"] = frame[cfg["education"]].map(lambda v: edu.get(_norm_text(v), "missing" if pd.isna(v) else "unknown"))
    t1 = pd.to_numeric(frame[cfg["treatment_climate"]], errors="coerce").fillna(0)
    t2 = pd.to_numeric(frame[cfg["treatment_policy"]], errors="coerce").fillna(0)
    out["exposure"] = np.where((t1 == 1) | (t2 == 1), "exposed", "control")
    out["country"] = frame[cfg["country"]].map(_country)
    target = pd.to_numeric(frame[cfg["target"]], errors="coerce")
    pnr = cfg.get("pnr_value", -0.1)
    keep = target.notna() & ~target.eq(pnr)
    out["y"] = np.where(keep, (target > 0).astype(float), np.nan)
    return out.loc[out["y"].notna()].reset_index(drop=True)

def read_source(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix == ".dta":
        return pd.read_stata(path)
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    raise ValueError(f"Unsupported source suffix: {suffix}")

def audit_frame(frame: pd.DataFrame) -> dict:
    return {
        "rows": int(len(frame)),
        "positive": int(frame["y"].sum()),
        "nonpositive": int((frame["y"] == 0).sum()),
        "prevalence": float(frame["y"].mean()),
        "countries": int(frame["country"].nunique(dropna=False)),
        "duplicate_row_ids": int(frame["row_id"].duplicated().sum()),
        "missing": {c: int(frame[c].isna().sum()) for c in ["age", "gender", "education", "exposure", "country"]},
    }
