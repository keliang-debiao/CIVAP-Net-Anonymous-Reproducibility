from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
import torch

SPECIAL_UNKNOWN = "<UNKNOWN>"
SPECIAL_MISSING = "<MISSING>"

def _hash_id(value: str) -> int:
    return int(hashlib.sha256(str(value).encode("utf-8")).hexdigest()[:15], 16)

@dataclass
class EncodedFrame:
    age: np.ndarray
    age_observed: np.ndarray
    gender: np.ndarray
    education: np.ndarray
    exposure: np.ndarray
    country: np.ndarray
    row_id: np.ndarray
    y: np.ndarray
    auxiliary: np.ndarray
    auxiliary_mask: np.ndarray
    country_text: np.ndarray

    def subset(self, indices) -> "EncodedFrame":
        idx = np.asarray(indices)
        return EncodedFrame(**{k: getattr(self, k)[idx] for k in self.__dataclass_fields__})

    def __len__(self):
        return len(self.y)

class FoldPreprocessor:
    categorical = ["gender", "education", "exposure", "country"]

    def __init__(self):
        self.age_median = None
        self.age_mean = None
        self.age_std = None
        self.vocab = {}
        self.country_counts = {}

    def fit(self, frame: pd.DataFrame) -> "FoldPreprocessor":
        age = pd.to_numeric(frame["age"], errors="coerce")
        self.age_median = float(age.median())
        filled = age.fillna(self.age_median)
        self.age_mean = float(filled.mean())
        self.age_std = float(filled.std(ddof=0)) or 1.0
        for col in self.categorical:
            values = sorted({str(v) for v in frame[col].dropna().tolist()})
            self.vocab[col] = {SPECIAL_UNKNOWN: 0, SPECIAL_MISSING: 1, **{v: i + 2 for i, v in enumerate(values)}}
        self.country_counts = frame["country"].astype(str).value_counts().to_dict()
        return self

    def _map(self, series: pd.Series, col: str) -> np.ndarray:
        vocab = self.vocab[col]
        def convert(v):
            if pd.isna(v):
                return vocab[SPECIAL_MISSING]
            return vocab.get(str(v), vocab[SPECIAL_UNKNOWN])
        return series.map(convert).to_numpy(dtype=np.int64)

    def transform(self, frame: pd.DataFrame, auxiliary_count: int = 8) -> EncodedFrame:
        if self.age_median is None:
            raise RuntimeError("Preprocessor must be fitted before transform")
        raw_age = pd.to_numeric(frame["age"], errors="coerce")
        age_observed = raw_age.notna().to_numpy(dtype=np.float32)
        age = ((raw_age.fillna(self.age_median) - self.age_mean) / self.age_std).to_numpy(dtype=np.float32)
        aux = np.full((len(frame), auxiliary_count), np.nan, dtype=np.float32)
        for j in range(auxiliary_count):
            col = f"aux_{j + 1}"
            if col in frame.columns:
                aux[:, j] = pd.to_numeric(frame[col], errors="coerce").to_numpy(dtype=np.float32)
        aux_mask = np.isfinite(aux).astype(np.float32)
        aux = np.nan_to_num(aux, nan=0.0)
        return EncodedFrame(
            age=age,
            age_observed=age_observed,
            gender=self._map(frame["gender"], "gender"),
            education=self._map(frame["education"], "education"),
            exposure=self._map(frame["exposure"], "exposure"),
            country=self._map(frame["country"], "country"),
            row_id=np.asarray([_hash_id(v) for v in frame["row_id"].astype(str)], dtype=np.int64),
            y=frame["y"].astype(float).to_numpy(dtype=np.float32),
            auxiliary=aux,
            auxiliary_mask=aux_mask,
            country_text=frame["country"].astype(str).to_numpy(),
        )

    def state_dict(self) -> dict:
        return {"age_median":self.age_median,"age_mean":self.age_mean,"age_std":self.age_std,"vocab":self.vocab,"country_counts":self.country_counts}

    @classmethod
    def from_state_dict(cls, state: dict) -> "FoldPreprocessor":
        obj = cls(); obj.age_median=state["age_median"]; obj.age_mean=state["age_mean"]; obj.age_std=state["age_std"]
        obj.vocab={k:{str(kk):int(vv) for kk,vv in v.items()} for k,v in state["vocab"].items()}; obj.country_counts=state["country_counts"]
        return obj

    def save(self, path: str | Path) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(json.dumps(self.state_dict(), indent=2, sort_keys=True), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "FoldPreprocessor":
        return cls.from_state_dict(json.loads(Path(path).read_text(encoding="utf-8")))

def tensor_batch(encoded: EncodedFrame, indices, device: str | torch.device) -> dict[str, torch.Tensor]:
    idx = np.asarray(indices)
    def t(name, dtype): return torch.as_tensor(getattr(encoded, name)[idx], dtype=dtype, device=device)
    return {
        "age": t("age", torch.float32), "age_observed": t("age_observed", torch.float32),
        "gender": t("gender", torch.long), "education": t("education", torch.long),
        "exposure": t("exposure", torch.long), "country": t("country", torch.long),
        "row_id": t("row_id", torch.long), "y": t("y", torch.float32),
        "auxiliary": t("auxiliary", torch.float32), "auxiliary_mask": t("auxiliary_mask", torch.float32),
    }
