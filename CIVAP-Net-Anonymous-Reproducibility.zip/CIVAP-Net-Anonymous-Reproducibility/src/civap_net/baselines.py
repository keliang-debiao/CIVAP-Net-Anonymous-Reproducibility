from __future__ import annotations
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder,StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from .neural_baselines import FTTransformerClassifier

NUMERIC=["age"]
CATEGORICAL=["gender","education","exposure","country"]

def common_transformer():
    num=Pipeline([("impute",SimpleImputer(strategy="median")),("scale",StandardScaler())])
    cat=Pipeline([("impute",SimpleImputer(strategy="most_frequent")),("onehot",OneHotEncoder(handle_unknown="ignore",sparse_output=False))])
    return ColumnTransformer([("numeric",num,NUMERIC),("categorical",cat,CATEGORICAL)])

def build_baseline(name,cfg,seed=2026):
    if name=="logistic_regression":
        model=LogisticRegression(C=float(cfg["C"]),penalty="l2",class_weight=cfg.get("class_weight"),max_iter=int(cfg["max_iter"]),random_state=seed)
    elif name=="random_forest":
        model=RandomForestClassifier(n_estimators=int(cfg["n_estimators"]),max_depth=int(cfg["max_depth"]),min_samples_leaf=int(cfg["min_samples_leaf"]),max_features=cfg["max_features"],n_jobs=-1,random_state=seed)
    elif name=="mlp":
        model=MLPClassifier(hidden_layer_sizes=tuple(cfg["hidden_layer_sizes"]),early_stopping=True,max_iter=120,random_state=seed)
    elif name=="xgboost":
        from xgboost import XGBClassifier
        model=XGBClassifier(**cfg,eval_metric="logloss",random_state=seed,n_jobs=-1)
    elif name=="lightgbm":
        from lightgbm import LGBMClassifier
        model=LGBMClassifier(**cfg,random_state=seed,n_jobs=-1,verbosity=-1)
    elif name=="tabnet":
        from pytorch_tabnet.tab_model import TabNetClassifier
        model=TabNetClassifier(n_d=int(cfg["n_d"]),n_a=int(cfg["n_a"]),n_steps=int(cfg["n_steps"]),gamma=float(cfg["gamma"]),seed=seed,verbose=0)
    elif name=="ft_transformer":
        return FTTransformerClassifier(cfg,seed=seed)
    elif name in {"tabicl","tabiclv2"}:
        from tabicl import TabICLClassifier
        checkpoint="tabicl-classifier-v1-20250208.ckpt" if name=="tabicl" else "tabicl-classifier-v2-20260212.ckpt"
        return TabICLClassifier(n_estimators=int(cfg["ensemble_members"]),checkpoint_version=checkpoint,random_state=seed,kv_cache=True)
    else:
        raise KeyError(f"Unsupported built-in baseline: {name}")
    return Pipeline([("transform",common_transformer()),("model",model)])
