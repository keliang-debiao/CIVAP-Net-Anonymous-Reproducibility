from __future__ import annotations
from pathlib import Path
from datetime import datetime,timezone
import importlib.metadata
import json
import platform
import sys
from .config import canonical_digest

def environment_fingerprint():
    packages={}
    for name in ["numpy","pandas","scipy","scikit-learn","torch","faiss-cpu","xgboost","lightgbm","pytorch-tabnet","tabicl","pytest"]:
        try: packages[name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError: packages[name]=None
    return {"python":sys.version.split()[0],"platform":platform.platform(),"packages":packages}

def write_run_record(path,command,seed,config,input_digests,status,artifacts=None,details=None):
    record={"record_type":"machine_execution","utc":datetime.now(timezone.utc).isoformat(),"command":command,"seed":seed,"configuration_sha256":canonical_digest(config),"input_sha256":input_digests,"environment":environment_fingerprint(),"status":status,"artifacts":artifacts or [],"details":details or {}}
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(record,indent=2,sort_keys=True),encoding="utf-8")
    return record
