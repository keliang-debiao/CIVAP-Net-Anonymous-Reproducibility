from __future__ import annotations
from copy import deepcopy
import random
import numpy as np
import pandas as pd
import torch
from torch import nn
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedShuffleSplit

FIELDS=("gender","education","exposure","country")

class _Encoder:
    def fit(self,x):
        age=pd.to_numeric(x["age"],errors="coerce"); self.median=float(age.median()); filled=age.fillna(self.median)
        self.mean=float(filled.mean()); self.std=float(filled.std(ddof=0)) or 1.0
        self.vocab={c:{"<UNKNOWN>":0,"<MISSING>":1,**{v:i+2 for i,v in enumerate(sorted({str(z) for z in x[c].dropna()}))}} for c in FIELDS}
        return self
    def transform(self,x):
        age=pd.to_numeric(x["age"],errors="coerce").fillna(self.median); age=((age-self.mean)/self.std).to_numpy(np.float32)[:,None]
        cats=[]
        for c in FIELDS:
            vocab=self.vocab[c]
            cats.append(x[c].map(lambda z:vocab["<MISSING>"] if pd.isna(z) else vocab.get(str(z),0)).to_numpy(np.int64))
        return age,np.column_stack(cats)

class _FTModel(nn.Module):
    def __init__(self,cardinalities,cfg):
        super().__init__(); d=int(cfg["dimension"])
        self.num_weight=nn.Parameter(torch.empty(1,d)); self.num_bias=nn.Parameter(torch.zeros(1,d)); nn.init.normal_(self.num_weight,std=0.02)
        self.cat=nn.ModuleList([nn.Embedding(int(n),d) for n in cardinalities]); self.cls=nn.Parameter(torch.zeros(1,1,d))
        layer=nn.TransformerEncoderLayer(d_model=d,nhead=int(cfg["heads"]),dim_feedforward=int(cfg["ffn_dimension"]),dropout=float(cfg["dropout"]),batch_first=True,norm_first=True)
        self.body=nn.TransformerEncoder(layer,num_layers=int(cfg["blocks"])); self.head=nn.Sequential(nn.LayerNorm(d),nn.ReLU(),nn.Linear(d,1))
    def forward(self,num,cat):
        tokens=[num.unsqueeze(-1)*self.num_weight.unsqueeze(0)+self.num_bias.unsqueeze(0)]
        tokens.extend(emb(cat[:,j]).unsqueeze(1) for j,emb in enumerate(self.cat))
        cls=self.cls.expand(len(num),-1,-1); z=self.body(torch.cat([cls]+tokens,dim=1)); return self.head(z[:,0]).squeeze(-1)

class FTTransformerClassifier:
    def __init__(self,cfg,seed=2026): self.cfg=dict(cfg); self.seed=int(seed)
    def fit(self,x,y):
        random.seed(self.seed); np.random.seed(self.seed); torch.manual_seed(self.seed)
        x=x.reset_index(drop=True); y=np.asarray(y,dtype=np.float32); split=StratifiedShuffleSplit(n_splits=1,test_size=0.12,random_state=self.seed)
        fit_idx,stop_idx=next(split.split(x,y)); self.encoder_=_Encoder().fit(x.iloc[fit_idx]); num,cat=self.encoder_.transform(x); device="cuda" if torch.cuda.is_available() else "cpu"
        self.model_=_FTModel([len(self.encoder_.vocab[c]) for c in FIELDS],self.cfg).to(device); opt=torch.optim.AdamW(self.model_.parameters(),lr=3e-4,weight_decay=1e-4)
        best=None; best_auc=-np.inf; stale=0; batch=512
        for epoch in range(120):
            self.model_.train(); order=np.random.default_rng(self.seed+epoch).permutation(fit_idx)
            for start in range(0,len(order),batch):
                idx=order[start:start+batch]; xn=torch.as_tensor(num[idx],device=device); xc=torch.as_tensor(cat[idx],device=device); yy=torch.as_tensor(y[idx],device=device)
                opt.zero_grad(set_to_none=True); loss=nn.functional.binary_cross_entropy_with_logits(self.model_(xn,xc),yy); loss.backward(); torch.nn.utils.clip_grad_norm_(self.model_.parameters(),1.0); opt.step()
            p=self._predict_arrays(num[stop_idx],cat[stop_idx],device)[:,1]; auc=roc_auc_score(y[stop_idx],p)
            if auc>best_auc+1e-8: best_auc=auc; best=deepcopy(self.model_.state_dict()); stale=0
            else: stale+=1
            if stale>=15: break
        self.model_.load_state_dict(best); self.device_=device; self.classes_=np.array([0,1]); return self
    def _predict_arrays(self,num,cat,device):
        self.model_.eval(); values=[]
        with torch.no_grad():
            for start in range(0,len(num),2048):
                z=self.model_(torch.as_tensor(num[start:start+2048],device=device),torch.as_tensor(cat[start:start+2048],device=device)); values.append(torch.sigmoid(z).cpu().numpy())
        p=np.concatenate(values); return np.column_stack([1-p,p])
    def predict_proba(self,x):
        num,cat=self.encoder_.transform(x.reset_index(drop=True)); return self._predict_arrays(num,cat,self.device_)
