from __future__ import annotations
import torch
from torch import nn
import torch.nn.functional as F
from .retrieval import RetrievalBank, retrieve

class CIVAPNet(nn.Module):
    def __init__(self, vocab_sizes: dict[str,int], country_counts: dict[str,int], country_vocab: dict[str,int], cfg: dict):
        super().__init__()
        d=int(cfg["dimension"]); heads=int(cfg["attention_heads"]); ffn=int(cfg["ffn_dimension"])
        self.cfg=cfg; self.d=d; self.k=int(cfg["neighbors"]); self.tau=float(cfg["retrieval_temperature"])
        self.age_proj=nn.Linear(1,d); self.age_missing=nn.Parameter(torch.zeros(d))
        self.gender_emb=nn.Embedding(vocab_sizes["gender"],d)
        self.education_emb=nn.Embedding(vocab_sizes["education"],d)
        self.exposure_emb=nn.Embedding(vocab_sizes["exposure"],d)
        self.field_emb=nn.Parameter(torch.zeros(3,d))
        layer=nn.TransformerEncoderLayer(d_model=d,nhead=heads,dim_feedforward=ffn,dropout=float(cfg["dropout"]),batch_first=True,norm_first=True)
        self.profile_encoder=nn.TransformerEncoder(layer,num_layers=int(cfg["token_blocks"]))
        rank=int(cfg["interaction_rank"])
        self.profile_rank=nn.Linear(d,rank,bias=False); self.exposure_rank=nn.Linear(d,rank,bias=False); self.interaction_out=nn.Linear(rank,d)
        self.key_proj=nn.Linear(2*d,int(cfg["retrieval_key_dimension"]))
        self.context_state_proj=nn.Linear(d,d); self.label_emb=nn.Embedding(2,d)
        country_dim=int(cfg["country_dimension"])
        self.country_emb=nn.Embedding(vocab_sizes["country"],country_dim,padding_idx=0)
        shrink=torch.zeros(vocab_sizes["country"],dtype=torch.float32)
        train_count=torch.zeros(vocab_sizes["country"],dtype=torch.long)
        kappa=float(cfg["country_shrinkage_kappa"])
        for name,idx in country_vocab.items():
            n=float(country_counts.get(name,0)); shrink[idx]=n/(n+kappa) if idx>1 else 0.0; train_count[idx]=int(n)
        self.register_buffer("country_shrink",shrink)
        self.register_buffer("country_train_count",train_count)
        self.fusion=nn.Sequential(nn.Linear(3*d+country_dim,d),nn.LayerNorm(d),nn.GELU(),nn.Dropout(float(cfg["dropout"])))
        self.output=nn.Linear(d,1); self.auxiliary=nn.Linear(d,int(cfg["auxiliary_count"]))

    def encode_profile(self,batch):
        age_token=self.age_proj(batch["age"].unsqueeze(-1))
        age_token=torch.where(batch["age_observed"].unsqueeze(-1).bool(),age_token,self.age_missing.unsqueeze(0))
        tokens=torch.stack([age_token,self.gender_emb(batch["gender"]),self.education_emb(batch["education"])],dim=1)
        tokens=tokens+self.field_emb.unsqueeze(0)
        return self.profile_encoder(tokens).mean(dim=1)

    def encode_bank_fields(self,batch):
        h=self.encode_profile(batch); e=self.exposure_emb(batch["exposure"])
        key=F.normalize(self.key_proj(torch.cat([h,e],dim=-1)),dim=-1)
        return h,key,e

    def make_bank(self,batch):
        training=self.training; self.eval()
        with torch.no_grad():
            h,key,_=self.encode_bank_fields(batch)
        if training: self.train()
        return RetrievalBank(key.detach(),h.detach(),batch["y"].long().detach(),batch["row_id"].detach())

    def forward(self,batch,bank:RetrievalBank|None=None):
        h,key,e=self.encode_bank_fields(batch)
        if bool(self.cfg["modules"]["exposure_interaction"]):
            q=self.interaction_out(self.profile_rank(h)*self.exposure_rank(e))
        else:
            q=torch.zeros_like(h)
        if bank is not None and bool(self.cfg["modules"]["retrieval"]):
            idx,w=retrieve(key,batch["row_id"],bank,self.k,self.tau)
            states=bank.states[idx]; labels=bank.labels[idx]
            ctx=(w.unsqueeze(-1)*(self.context_state_proj(states)+self.label_emb(labels))).sum(dim=1)
        else:
            ctx=torch.zeros_like(h)
        if bool(self.cfg["modules"]["country_residual"]):
            c=self.country_emb(batch["country"])*self.country_shrink[batch["country"]].unsqueeze(-1)
        else:
            c=torch.zeros((len(h),self.country_emb.embedding_dim),device=h.device)
        u=self.fusion(torch.cat([h,q,ctx,c],dim=-1))
        return {"logit":self.output(u).squeeze(-1),"auxiliary":torch.sigmoid(self.auxiliary(u)),"state":h,"key":key}
