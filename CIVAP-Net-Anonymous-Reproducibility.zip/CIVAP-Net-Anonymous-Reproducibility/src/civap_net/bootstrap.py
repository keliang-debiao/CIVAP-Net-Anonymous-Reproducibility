from __future__ import annotations
import numpy as np
from sklearn.metrics import roc_auc_score
from scipy.stats import norm

def paired_country_bootstrap(y,p_a,p_b,countries,repetitions=5000,seed=2026):
    y=np.asarray(y); p_a=np.asarray(p_a); p_b=np.asarray(p_b); countries=np.asarray(countries)
    unique=np.unique(countries); rng=np.random.default_rng(seed); diffs=[]
    for _ in range(repetitions):
        selected=rng.choice(unique,size=len(unique),replace=True); indices=[]
        for c in selected:
            pool=np.flatnonzero(countries==c); indices.extend(rng.choice(pool,size=len(pool),replace=True).tolist())
        idx=np.asarray(indices,dtype=int)
        if len(np.unique(y[idx]))<2: continue
        diffs.append(roc_auc_score(y[idx],p_a[idx])-roc_auc_score(y[idx],p_b[idx]))
    diffs=np.asarray(diffs); observed=roc_auc_score(y,p_a)-roc_auc_score(y,p_b)
    p=2*min((np.sum(diffs<=0)+1)/(len(diffs)+1),(np.sum(diffs>=0)+1)/(len(diffs)+1))
    sd=float(diffs.std(ddof=1))
    return {"difference":float(observed),"ci_low":float(np.quantile(diffs,0.025)),"ci_high":float(np.quantile(diffs,0.975)),"p":float(min(1,p)),"effect_size_standardized":float(observed/sd) if sd>0 else float("nan"),"bootstrap_sd":sd,"replications":int(len(diffs))}

def _midrank(values):
    order=np.argsort(values); sorted_values=values[order]; n=len(values); ranks=np.zeros(n); i=0
    while i<n:
        j=i
        while j<n and sorted_values[j]==sorted_values[i]: j+=1
        ranks[i:j]=0.5*(i+j-1)+1; i=j
    out=np.empty(n); out[order]=ranks; return out

def _fast_delong(predictions_sorted,label_one_count):
    m=int(label_one_count); n=predictions_sorted.shape[1]-m; positive=predictions_sorted[:,:m]; negative=predictions_sorted[:,m:]; k=predictions_sorted.shape[0]; tx=np.empty((k,m)); ty=np.empty((k,n)); tz=np.empty((k,m+n))
    for r in range(k): tx[r]=_midrank(positive[r]); ty[r]=_midrank(negative[r]); tz[r]=_midrank(predictions_sorted[r])
    aucs=tz[:,:m].sum(axis=1)/(m*n)-(m+1)/(2*n); v01=(tz[:,:m]-tx)/n; v10=1-(tz[:,m:]-ty)/m; covariance=np.cov(v01)/m+np.cov(v10)/n
    return aucs,np.atleast_2d(covariance)

def paired_delong_test(y,p_a,p_b):
    y=np.asarray(y,dtype=int); scores=np.vstack([np.asarray(p_a,dtype=float),np.asarray(p_b,dtype=float)]); order=np.argsort(-y); m=int(y.sum())
    if m==0 or m==len(y): raise ValueError("Both outcome classes are required")
    aucs,covariance=_fast_delong(scores[:,order],m); contrast=np.array([1.0,-1.0]); variance=float(contrast@covariance@contrast); z=float((aucs[0]-aucs[1])/np.sqrt(max(variance,1e-15))); return {"difference":float(aucs[0]-aucs[1]),"z":z,"p":float(2*norm.sf(abs(z)))}

def holm_adjust(p_values):
    p=np.asarray(p_values,dtype=float); order=np.argsort(p); out=np.empty_like(p); running=0.0; m=len(p)
    for rank,idx in enumerate(order):
        running=max(running,(m-rank)*p[idx]); out[idx]=min(1.0,running)
    return out
