from __future__ import annotations
import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import StratifiedShuffleSplit
from .preprocessing import FoldPreprocessor
from .model import CIVAPNet
from .training import fit_model,predict_logits,set_seed
from .calibration import fit_temperature,apply_temperature,select_f1_threshold
from .splits import make_inner_folds

def _model(pre,cfg):
    return CIVAPNet({k:len(v) for k,v in pre.vocab.items()},pre.country_counts,pre.vocab["country"],cfg)

def cross_validated_predictions(frame,assignments,model_cfg,training,seed,device,training_fraction=1.0):
    assignments=np.asarray(assignments); output=[]
    for fold in sorted(np.unique(assignments)):
        train_df=frame.loc[assignments!=fold].reset_index(drop=True); val_df=frame.loc[assignments==fold].reset_index(drop=True)
        if training_fraction<1.0:
            sampler=StratifiedShuffleSplit(n_splits=1,train_size=training_fraction,random_state=seed+int(fold)); keep,_=next(sampler.split(train_df,train_df.y.astype(int))); train_df=train_df.iloc[keep].reset_index(drop=True)
        inner=make_inner_folds(train_df,int(training["inner_folds"]),seed+int(fold)); inner_logits=np.full(len(train_df),np.nan)
        for inner_fold in range(1,int(training["inner_folds"])+1):
            inner_train=train_df.loc[inner!=inner_fold].reset_index(drop=True); inner_val=train_df.loc[inner==inner_fold].reset_index(drop=True); split=StratifiedShuffleSplit(n_splits=1,test_size=0.12,random_state=seed+100*int(fold)+inner_fold); fit_idx,stop_idx=next(split.split(inner_train,inner_train.y.astype(int)))
            pre=FoldPreprocessor().fit(inner_train); fit_data=pre.transform(inner_train.iloc[fit_idx]); stop_data=pre.transform(inner_train.iloc[stop_idx]); val_data=pre.transform(inner_val); run_seed=seed+1000*int(fold)+inner_fold; set_seed(run_seed); model=_model(pre,model_cfg); model,bank,_=fit_model(model,fit_data,stop_data,training,device,run_seed); inner_logits[np.flatnonzero(inner==inner_fold)]=predict_logits(model,val_data,bank,device)
        temperature=fit_temperature(inner_logits,train_df.y.astype(int)); threshold=select_f1_threshold(train_df.y.astype(int),apply_temperature(inner_logits,temperature)); split=StratifiedShuffleSplit(n_splits=1,test_size=0.12,random_state=seed+int(fold)); fit_idx,stop_idx=next(split.split(train_df,train_df.y.astype(int))); pre=FoldPreprocessor().fit(train_df); fit_data=pre.transform(train_df.iloc[fit_idx]); stop_data=pre.transform(train_df.iloc[stop_idx]); val_data=pre.transform(val_df); set_seed(seed+int(fold)); model=_model(pre,model_cfg); model,bank,_=fit_model(model,fit_data,stop_data,training,device,seed+int(fold)); raw=predict_logits(model,val_data,bank,device); probability=apply_temperature(raw,temperature)
        output.append(pd.DataFrame({"row_id":val_df.row_id,"country":val_df.country,"y":val_data.y,"fold":fold,"logit":raw,"probability":probability,"threshold":threshold}))
    return pd.concat(output,ignore_index=True)
