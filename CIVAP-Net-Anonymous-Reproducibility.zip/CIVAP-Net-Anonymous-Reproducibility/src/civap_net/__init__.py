"""CIVAP-Net reproducibility implementation."""

__version__ = "1.0.0"
