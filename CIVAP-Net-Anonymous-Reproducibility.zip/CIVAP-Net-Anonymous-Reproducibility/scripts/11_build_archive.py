from _bootstrap import ROOT
from pathlib import Path
import hashlib
import zipfile

EXCLUDE={"data/raw","data/processed","outputs/checkpoints","outputs/predictions","outputs/retrieval_banks","outputs/figures",".venv",".git","__pycache__",".pytest_cache"}
EXCLUDED_PARTS={".venv",".git","__pycache__",".pytest_cache"}

def excluded(rel):
    text=rel.as_posix(); return any(part in EXCLUDED_PARTS for part in rel.parts) or any(text==x or text.startswith(x+"/") for x in EXCLUDE)

def main():
    files=[p for p in ROOT.rglob("*") if p.is_file() and not excluded(p.relative_to(ROOT)) and p.name!="SHA256SUMS.txt"]
    checks=[]
    for p in sorted(files): checks.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT).as_posix()}")
    (ROOT/"SHA256SUMS.txt").write_text("\n".join(checks)+"\n",encoding="utf-8"); files.append(ROOT/"SHA256SUMS.txt")
    archive=ROOT.parent/(ROOT.name+".zip")
    with zipfile.ZipFile(archive,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(files): z.write(p,arcname=f"{ROOT.name}/{p.relative_to(ROOT).as_posix()}")
    print(archive)

if __name__=="__main__": main()
