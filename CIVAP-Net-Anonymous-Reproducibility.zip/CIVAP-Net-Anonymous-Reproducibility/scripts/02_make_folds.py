from _bootstrap import ROOT
import pandas as pd
from civap_net.config import load_yaml,file_sha256
from civap_net.splits import make_outer_folds,make_inner_folds
from civap_net.io_utils import ensure_dirs
from civap_net.logging_utils import write_run_record

def main():
    ensure_dirs(); dcfg=load_yaml(ROOT/"configs/datasets.yaml"); tcfg=load_yaml(ROOT/"configs/training.yaml")
    path=ROOT/dcfg["processed"]["development"]; frame=pd.read_csv(path)
    outer=make_outer_folds(frame,int(tcfg["outer_folds"]),int(tcfg["outer_seed"])); outer.to_csv(ROOT/"outputs/folds/outer_folds.csv",index=False)
    inner_rows=[]
    for fold in range(1,int(tcfg["outer_folds"])+1):
        train=frame.loc[outer["fold"].to_numpy()!=fold].reset_index(drop=True); assignments=make_inner_folds(train,int(tcfg["inner_folds"]),int(tcfg["outer_seed"]))
        inner_rows.extend({"outer_fold":fold,"row_id":r,"inner_fold":int(k)} for r,k in zip(train["row_id"],assignments))
    pd.DataFrame(inner_rows).to_csv(ROOT/"outputs/folds/inner_folds.csv",index=False)
    write_run_record(ROOT/"outputs/logs/02_folds.json","make_folds",int(tcfg["outer_seed"]),{"datasets":dcfg,"training":tcfg},{str(path):file_sha256(path)},"completed",["outputs/folds/outer_folds.csv","outputs/folds/inner_folds.csv"])

if __name__=="__main__": main()
