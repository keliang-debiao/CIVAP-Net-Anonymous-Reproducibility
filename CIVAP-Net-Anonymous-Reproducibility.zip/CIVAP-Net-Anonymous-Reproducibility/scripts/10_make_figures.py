from _bootstrap import ROOT
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import roc_auc_score

def save(fig,name):
    out=ROOT/"outputs/figures"; out.mkdir(parents=True,exist_ok=True); fig.savefig(out/name,dpi=300,bbox_inches="tight"); plt.close(fig)

def cluster_auc_ci(frame,repetitions=2000,seed=2026):
    rng=np.random.default_rng(seed); countries=frame.country.unique(); values=[]
    for _ in range(repetitions):
        selected=rng.choice(countries,len(countries),replace=True); indices=[]
        for country in selected:
            pool=np.flatnonzero(frame.country.to_numpy()==country); indices.extend(rng.choice(pool,len(pool),replace=True))
        part=frame.iloc[np.asarray(indices,dtype=int)]
        if part.y.nunique()==2: values.append(roc_auc_score(part.y,part.probability))
    return np.quantile(values,[0.025,0.975])

def reliability(frame,bins=10):
    ordered=frame.sort_values("probability"); groups=np.array_split(np.arange(len(ordered)),bins); return np.asarray([ordered.iloc[idx].probability.mean() for idx in groups]),np.asarray([ordered.iloc[idx].y.mean() for idx in groups])

def main():
    sns.set_theme(style="whitegrid",context="paper")
    cv=ROOT/"outputs/metrics/civap_cv_metrics.csv"
    if cv.exists():
        df=pd.read_csv(cv); fig,ax=plt.subplots(figsize=(6.4,3.8)); ax.plot(df.fold,df.auroc,marker="o",label="AUROC"); ax.plot(df.fold,df.auprc,marker="s",label="AUPRC"); ax.set(xlabel="Outer fold",ylabel="Score",xticks=df.fold); ax.legend(frameon=False); save(fig,"figure_3_cv_performance.png")
    base=ROOT/"outputs/metrics/baseline_cv_metrics.csv"
    if base.exists():
        df=pd.read_csv(base); proposed=pd.read_csv(cv).assign(model="civap_net"); summary=pd.concat([df,proposed],ignore_index=True).groupby("model").auroc.agg(["mean","std"]).sort_values("mean"); fig,ax=plt.subplots(figsize=(6.4,4.2)); ax.errorbar(summary["mean"],range(len(summary)),xerr=summary["std"],fmt="o",capsize=3); ax.set(yticks=range(len(summary)),yticklabels=summary.index,xlabel="Mean AUROC ± SD",ylabel="Model"); save(fig,"figure_4_baseline_comparison.png")
    proposed_external=ROOT/"outputs/predictions/civap_external.csv"; baseline_external=ROOT/"outputs/predictions/baseline_external.csv"
    if proposed_external.exists() and baseline_external.exists():
        frames=[pd.read_csv(proposed_external).assign(model="civap_net")]; all_base=pd.read_csv(baseline_external); frames.extend([all_base.loc[all_base.model==m] for m in ["logistic_regression","lightgbm","tabiclv2"]]); points=[]
        for data in frames:
            lo,hi=cluster_auc_ci(data); auc=roc_auc_score(data.y,data.probability); points.append({"model":data.model.iloc[0],"auroc":auc,"low":lo,"high":hi})
        points=pd.DataFrame(points).sort_values("auroc"); fig,ax=plt.subplots(figsize=(6.4,3.8)); ax.errorbar(points.auroc,range(len(points)),xerr=np.vstack([points.auroc-points.low,points.high-points.auroc]),fmt="o",capsize=3); ax.set(yticks=range(len(points)),yticklabels=points.model,xlabel="External AUROC (95% country-cluster CI)",ylabel="Model"); save(fig,"figure_5_external_validation.png")
    ablation=ROOT/"outputs/metrics/ablation_summary.csv"
    if ablation.exists():
        data=pd.read_csv(ablation).query("variant != 'full'").sort_values("internal_delta"); fig,ax=plt.subplots(figsize=(6.4,4.0)); ax.errorbar(data.internal_delta,range(len(data)),xerr=np.vstack([data.internal_delta-data.internal_ci_low,data.internal_ci_high-data.internal_delta]),fmt="o",capsize=3); ax.axvline(0,color="black",linewidth=.8); ax.set(yticks=range(len(data)),yticklabels=data.variant,xlabel="AUROC decrease from complete model",ylabel="Ablation"); save(fig,"figure_6_ablation.png")
    robustness=ROOT/"outputs/metrics/robustness_summary.csv"
    if proposed_external.exists() and robustness.exists():
        development=pd.read_csv(ROOT/"outputs/predictions/civap_oof.csv")[["y","probability"]]; external=pd.read_csv(proposed_external)[["y","probability"]]; fig,axes=plt.subplots(1,2,figsize=(9.0,3.8));
        for data,label,marker in [(development,"Development","o"),(external,"External","s")]: x,y=reliability(data); axes[0].plot(x,y,marker=marker,label=label)
        axes[0].plot([0,1],[0,1],linestyle="--",color="black"); axes[0].set(xlabel="Mean predicted probability",ylabel="Observed proportion",title="(a) Calibration"); axes[0].legend(frameon=False)
        data=pd.read_csv(robustness).sort_values("auroc"); axes[1].barh(data.condition,data.auroc,xerr=data.auroc_sd.fillna(0),alpha=.8); axes[1].set(xlabel="AUROC",ylabel="Condition",title="(b) Robustness"); save(fig,"figure_7_calibration_robustness.png")
    contrasts=ROOT/"outputs/metrics/paired_contrasts.csv"; importance=ROOT/"outputs/metrics/permutation_importance_summary.csv"
    if contrasts.exists() and importance.exists():
        data=pd.read_csv(contrasts); labels=data.cohort+": "+data.comparator; fig,axes=plt.subplots(1,2,figsize=(9.4,4.2)); axes[0].errorbar(data.difference,range(len(data)),xerr=np.vstack([data.difference-data.ci_low,data.ci_high-data.difference]),fmt="o",capsize=3); axes[0].axvline(0,color="black",linewidth=.8); axes[0].set(yticks=range(len(data)),yticklabels=labels,xlabel="Paired AUROC difference",title="(a) Statistical contrasts"); imp=pd.read_csv(importance).sort_values("mean_auroc_decrease"); axes[1].errorbar(imp.mean_auroc_decrease,range(len(imp)),xerr=np.vstack([imp.mean_auroc_decrease-imp.ci_low,imp.ci_high-imp.mean_auroc_decrease]),fmt="o",capsize=3); axes[1].axvline(0,color="black",linewidth=.8); axes[1].set(yticks=range(len(imp)),yticklabels=imp.group,xlabel="AUROC decrease",title="(b) Grouped permutation"); save(fig,"figure_8_statistical_interpretability.png")
    print("Figures available from completed machine outputs were written to outputs/figures.")

if __name__=="__main__": main()
