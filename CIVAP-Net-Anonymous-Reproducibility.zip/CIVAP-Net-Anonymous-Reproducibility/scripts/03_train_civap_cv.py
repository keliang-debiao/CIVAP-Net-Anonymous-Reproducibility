from _bootstrap import ROOT
from pathlib import Path
import json
import time
import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import StratifiedShuffleSplit
from civap_net.config import load_yaml,file_sha256
from civap_net.preprocessing import FoldPreprocessor
from civap_net.model import CIVAPNet
from civap_net.training import fit_model,predict_logits,set_seed
from civap_net.splits import make_inner_folds
from civap_net.calibration import fit_temperature,apply_temperature,select_f1_threshold
from civap_net.metrics import binary_metrics
from civap_net.io_utils import ensure_dirs,write_json
from civap_net.logging_utils import write_run_record

def make_model(pre,cfg):
    sizes={k:len(v) for k,v in pre.vocab.items()}
    return CIVAPNet(sizes,pre.country_counts,pre.vocab["country"],cfg)

def main():
    ensure_dirs(); dcfg=load_yaml(ROOT/"configs/datasets.yaml"); mcfg=load_yaml(ROOT/"configs/model.yaml"); tcfg=load_yaml(ROOT/"configs/training.yaml")
    frame=pd.read_csv(ROOT/dcfg["processed"]["development"]); folds=pd.read_csv(ROOT/"outputs/folds/outer_folds.csv")
    fold_map=dict(zip(folds.row_id,folds.fold)); assigned=frame.row_id.map(fold_map).to_numpy(); device="cuda" if torch.cuda.is_available() else "cpu"; records=[]; pred_rows=[]
    for fold in range(1,int(tcfg["outer_folds"])+1):
        train_df=frame.loc[assigned!=fold].reset_index(drop=True); val_df=frame.loc[assigned==fold].reset_index(drop=True)
        inner_assignment=make_inner_folds(train_df,int(tcfg["inner_folds"]),int(tcfg["outer_seed"])+fold)
        inner_oof_logits=np.full(len(train_df),np.nan,dtype=float)
        for inner_fold in range(1,int(tcfg["inner_folds"])+1):
            inner_train_df=train_df.loc[inner_assignment!=inner_fold].reset_index(drop=True)
            inner_val_df=train_df.loc[inner_assignment==inner_fold].reset_index(drop=True)
            inner_split=StratifiedShuffleSplit(n_splits=1,test_size=0.12,random_state=int(tcfg["outer_seed"])+100*fold+inner_fold)
            inner_fit_idx,inner_stop_idx=next(inner_split.split(inner_train_df,inner_train_df.y.astype(int)))
            inner_pre=FoldPreprocessor().fit(inner_train_df)
            inner_fit=inner_pre.transform(inner_train_df.iloc[inner_fit_idx]); inner_stop=inner_pre.transform(inner_train_df.iloc[inner_stop_idx]); inner_val=inner_pre.transform(inner_val_df)
            inner_seed=int(tcfg["outer_seed"])+1000*fold+inner_fold
            set_seed(inner_seed); inner_model=make_model(inner_pre,mcfg)
            inner_model,inner_bank,_=fit_model(inner_model,inner_fit,inner_stop,tcfg,device,inner_seed)
            inner_oof_logits[np.flatnonzero(inner_assignment==inner_fold)]=predict_logits(inner_model,inner_val,inner_bank,device)
        if not np.isfinite(inner_oof_logits).all():
            raise RuntimeError(f"Incomplete inner out-of-fold predictions for outer fold {fold}")
        temperature=fit_temperature(inner_oof_logits,train_df.y.to_numpy(dtype=int))
        inner_probability=apply_temperature(inner_oof_logits,temperature)
        threshold=select_f1_threshold(train_df.y.to_numpy(dtype=int),inner_probability)
        split=StratifiedShuffleSplit(n_splits=1,test_size=0.12,random_state=int(tcfg["outer_seed"])+fold)
        fit_idx,stop_idx=next(split.split(train_df,train_df.y.astype(int)))
        pre=FoldPreprocessor().fit(train_df); train=pre.transform(train_df.iloc[fit_idx]); stop=pre.transform(train_df.iloc[stop_idx]); val=pre.transform(val_df)
        set_seed(int(tcfg["outer_seed"])+fold); model=make_model(pre,mcfg)
        if torch.cuda.is_available(): torch.cuda.reset_peak_memory_stats()
        started=time.perf_counter(); model,bank,history=fit_model(model,train,stop,tcfg,device,int(tcfg["outer_seed"])+fold); training_seconds=time.perf_counter()-started; peak_memory_gb=float(torch.cuda.max_memory_allocated()/1e9) if torch.cuda.is_available() else float("nan")
        raw=predict_logits(model,val,bank,device)
        prob=apply_temperature(raw,temperature); metrics=binary_metrics(val.y,prob,threshold); metrics.update({"fold":fold,"temperature":temperature,"threshold":threshold}); records.append(metrics)
        pred_rows.append(pd.DataFrame({"row_id":val_df.row_id,"country":val_df.country,"y":val.y,"fold":fold,"logit":raw,"probability":prob}))
        pre.save(ROOT/f"outputs/checkpoints/fold_{fold}_preprocessor.json")
        torch.save({"state_dict":model.state_dict(),"model_config":mcfg,"vocab_sizes":{k:len(v) for k,v in pre.vocab.items()},"country_counts":pre.country_counts,"country_vocab":pre.vocab["country"]},ROOT/f"outputs/checkpoints/fold_{fold}.pt")
        torch.save(bank,ROOT/f"outputs/retrieval_banks/fold_{fold}.pt")
        write_json(ROOT/f"outputs/logs/fold_{fold}_history.json",{"epochs":history,"training_seconds":training_seconds,"peak_gpu_memory_gb":peak_memory_gb,"device":device})
    pd.DataFrame(records).to_csv(ROOT/"outputs/metrics/civap_cv_metrics.csv",index=False); predictions=pd.concat(pred_rows,ignore_index=True); predictions.to_csv(ROOT/"outputs/predictions/civap_oof.csv",index=False)
    global_t=fit_temperature(predictions.logit,predictions.y); global_p=apply_temperature(predictions.logit,global_t); global_g=select_f1_threshold(predictions.y,global_p)
    write_json(ROOT/"outputs/checkpoints/external_postprocessing.json",{"temperature":global_t,"threshold":global_g,"fit_source":"development_oof_only"})
    write_run_record(ROOT/"outputs/logs/03_civap_cv.json","train_civap_cv",int(tcfg["outer_seed"]),{"model":mcfg,"training":tcfg},{str(ROOT/dcfg["processed"]["development"]):file_sha256(ROOT/dcfg["processed"]["development"])},"completed",["outputs/metrics/civap_cv_metrics.csv","outputs/predictions/civap_oof.csv","outputs/checkpoints/external_postprocessing.json"],{"device":device})

if __name__=="__main__": main()
