from _bootstrap import ROOT
import numpy as np
import pandas as pd
from civap_net.config import load_yaml
from civap_net.baselines import build_baseline
from civap_net.calibration import fit_temperature,apply_temperature,select_f1_threshold
from civap_net.metrics import binary_metrics
from civap_net.splits import make_inner_folds
from civap_net.io_utils import ensure_dirs
from civap_net.logging_utils import write_run_record

MODELS=["logistic_regression","random_forest","xgboost","lightgbm","mlp","tabnet","ft_transformer","tabicl","tabiclv2"]

def to_logit(probability):
    p=np.clip(np.asarray(probability,dtype=float),1e-7,1-1e-7); return np.log(p/(1-p))

def main():
    ensure_dirs(); dcfg=load_yaml(ROOT/"configs/datasets.yaml"); bcfg=load_yaml(ROOT/"configs/baselines.yaml"); tcfg=load_yaml(ROOT/"configs/training.yaml")
    frame=pd.read_csv(ROOT/dcfg["processed"]["development"]); external=pd.read_csv(ROOT/dcfg["processed"]["external"]); folds=pd.read_csv(ROOT/"outputs/folds/outer_folds.csv"); fold_map=dict(zip(folds.row_id,folds.fold)); assigned=frame.row_id.map(fold_map).to_numpy(); rows=[]; preds=[]; external_rows=[]; external_metrics=[]
    xcols=["age","gender","education","exposure","country"]
    for name in MODELS:
        model_preds=[]; fold_external=[]; fold_thresholds=[]
        for fold in range(1,6):
            train=frame.loc[assigned!=fold].reset_index(drop=True); val=frame.loc[assigned==fold].reset_index(drop=True); inner=make_inner_folds(train,int(tcfg["inner_folds"]),int(tcfg["outer_seed"])+fold); inner_prob=np.full(len(train),np.nan)
            for inner_fold in range(1,int(tcfg["inner_folds"])+1):
                inner_train=train.loc[inner!=inner_fold]; inner_val=train.loc[inner==inner_fold]; inner_model=build_baseline(name,bcfg[name],2026+100*fold+inner_fold); inner_model.fit(inner_train[xcols],inner_train.y.astype(int)); inner_prob[np.flatnonzero(inner==inner_fold)]=inner_model.predict_proba(inner_val[xcols])[:,1]
            temperature=fit_temperature(to_logit(inner_prob),train.y.astype(int)); threshold=select_f1_threshold(train.y.astype(int),apply_temperature(to_logit(inner_prob),temperature)); fold_thresholds.append(threshold)
            model=build_baseline(name,bcfg[name],2026+fold); model.fit(train[xcols],train.y.astype(int)); raw=model.predict_proba(val[xcols])[:,1]; p=apply_temperature(to_logit(raw),temperature); ext=apply_temperature(to_logit(model.predict_proba(external[xcols])[:,1]),temperature); fold_external.append(ext)
            model_preds.append(pd.DataFrame({"row_id":val.row_id,"country":val.country,"y":val.y.astype(int),"fold":fold,"probability":p,"temperature":temperature,"threshold":threshold,"model":name}))
        full=pd.concat(model_preds,ignore_index=True); metrics=[]
        for fold in range(1,6):
            part=full.loc[full.fold==fold]; metrics.append(binary_metrics(part.y,part.probability,float(part.threshold.iloc[0]))|{"fold":fold,"model":name})
        ext_probability=np.mean(np.vstack(fold_external),axis=0); ext_threshold=float(np.median(fold_thresholds)); ext_metric=binary_metrics(external.y,ext_probability,ext_threshold)|{"model":name,"threshold":ext_threshold}; external_metrics.append(ext_metric); external_rows.append(pd.DataFrame({"row_id":external.row_id,"country":external.country,"y":external.y.astype(int),"probability":ext_probability,"model":name}))
        rows.extend(metrics); preds.append(full)
    pd.DataFrame(rows).to_csv(ROOT/"outputs/metrics/baseline_cv_metrics.csv",index=False); pd.concat(preds).to_csv(ROOT/"outputs/predictions/baseline_oof.csv",index=False)
    pd.DataFrame(external_metrics).to_csv(ROOT/"outputs/metrics/baseline_external_metrics.csv",index=False); pd.concat(external_rows).to_csv(ROOT/"outputs/predictions/baseline_external.csv",index=False)
    write_run_record(ROOT/"outputs/logs/04_baselines.json","train_baselines",2026,{"baselines":bcfg,"training":tcfg},{},"completed",["outputs/metrics/baseline_cv_metrics.csv","outputs/predictions/baseline_oof.csv","outputs/metrics/baseline_external_metrics.csv","outputs/predictions/baseline_external.csv"],{"models":MODELS,"foundation_registry":"manifests/foundation_models.json"})

if __name__=="__main__": main()
