from pathlib import Path
import json
import sys
import yaml
from _bootstrap import ROOT

TOKENS=["exam"+"ple","to"+"y","illust"+"rative",chr(0x6A21)+chr(0x62DF)]
LOCAL_PATTERNS=["/"+"workspace"+"/","c:"+chr(92)+"users"+chr(92)]
TEXT_SUFFIXES={".py",".md",".yaml",".yml",".json",".toml",".txt",".csv",".cff",".sh",".log"}

def main():
    failures=[]
    for path in ROOT.rglob("*"):
        rel=str(path.relative_to(ROOT))
        low=rel.lower()
        if any(token.lower() in low for token in TOKENS): failures.append(f"blocked path token: {rel}")
        if path.is_file() and path.suffix.lower() in TEXT_SUFFIXES:
            text=path.read_text(encoding="utf-8",errors="ignore").lower()
            for token in TOKENS:
                if token.lower() in text: failures.append(f"blocked content token: {rel}")
            if any(item in text for item in LOCAL_PATTERNS): failures.append(f"local path: {rel}")
    for cfg in (ROOT/"configs").glob("*.yaml"):
        yaml.safe_load(cfg.read_text(encoding="utf-8"))
    json.loads((ROOT/"manifests/run_contract.json").read_text(encoding="utf-8"))
    if failures:
        print("PACKAGE_VALIDATION_FAILED")
        for item in failures: print(item)
        return 1
    print("PACKAGE_VALIDATION_PASSED")
    print(f"checked_root={ROOT.name}")
    print(f"text_files={sum(1 for p in ROOT.rglob('*') if p.is_file() and p.suffix.lower() in TEXT_SUFFIXES)}")
    return 0

if __name__=="__main__": raise SystemExit(main())
