from _bootstrap import ROOT
import json
import time
import numpy as np
import pandas as pd
import torch
from scipy.stats import t
from civap_net.config import load_yaml
from civap_net.preprocessing import FoldPreprocessor,tensor_batch
from civap_net.model import CIVAPNet
from civap_net.training import predict_logits
from civap_net.calibration import apply_temperature
from civap_net.interpretability import GROUP_FIELDS,permute_group,importance_drop,kendalls_w
from civap_net.bootstrap import holm_adjust
from civap_net.io_utils import ensure_dirs
from civap_net.logging_utils import write_run_record

def load_fold(fold,device):
    state=torch.load(ROOT/f"outputs/checkpoints/fold_{fold}.pt",map_location=device,weights_only=False); pre=FoldPreprocessor.load(ROOT/f"outputs/checkpoints/fold_{fold}_preprocessor.json"); model=CIVAPNet(state["vocab_sizes"],state["country_counts"],state["country_vocab"],state["model_config"]).to(device); model.load_state_dict(state["state_dict"]); bank=torch.load(ROOT/f"outputs/retrieval_banks/fold_{fold}.pt",map_location=device,weights_only=False).to(device); model.eval(); return model,pre,bank

def main():
    ensure_dirs(); cfg=load_yaml(ROOT/"configs/robustness.yaml"); datasets=load_yaml(ROOT/"configs/datasets.yaml"); frame=pd.read_csv(ROOT/datasets["processed"]["development"]); folds=pd.read_csv(ROOT/"outputs/folds/outer_folds.csv"); fold_map=dict(zip(folds.row_id,folds.fold)); assigned=frame.row_id.map(fold_map).to_numpy(); post=pd.read_csv(ROOT/"outputs/metrics/civap_cv_metrics.csv").set_index("fold"); device="cuda" if torch.cuda.is_available() else "cpu"; rows=[]; fold_ranks=[]
    for fold in range(1,6):
        subset=frame.loc[assigned==fold].reset_index(drop=True); model,pre,bank=load_fold(fold,device); encoded=pre.transform(subset); base=apply_temperature(predict_logits(model,encoded,bank,device),float(post.loc[fold,"temperature"])); fold_means=[]
        for group in GROUP_FIELDS:
            values=[]
            for repetition in range(int(cfg["permutation_repetitions"])):
                changed=permute_group(encoded,group,2026+10000*fold+repetition); probability=apply_temperature(predict_logits(model,changed,bank,device),float(post.loc[fold,"temperature"])); drop=importance_drop(encoded.y,base,probability); rows.append({"fold":fold,"group":group,"repetition":repetition,"auroc_decrease":drop}); values.append(drop)
            fold_means.append(float(np.mean(values)))
        fold_ranks.append(pd.Series(fold_means,index=list(GROUP_FIELDS)).rank(ascending=False,method="average").to_numpy())
    detail=pd.DataFrame(rows); detail.to_csv(ROOT/"outputs/metrics/permutation_importance_detail.csv",index=False); summaries=[]
    for group,part in detail.groupby("group",sort=False):
        by_fold=part.groupby("fold").auroc_decrease.mean().to_numpy(); mean=float(by_fold.mean()); sd=float(by_fold.std(ddof=1)); half=float(t.ppf(0.975,len(by_fold)-1)*sd/np.sqrt(len(by_fold))); p=float((1+np.sum(part.auroc_decrease.to_numpy()<=0))/(len(part)+1)); summaries.append({"group":group,"mean_auroc_decrease":mean,"sd":sd,"ci_low":mean-half,"ci_high":mean+half,"permutation_p":p})
    adjusted=holm_adjust([row["permutation_p"] for row in summaries])
    for row,value in zip(summaries,adjusted): row["holm_p"]=float(value)
    pd.DataFrame(summaries).to_csv(ROOT/"outputs/metrics/permutation_importance_summary.csv",index=False); stability={"kendalls_w":kendalls_w(np.vstack(fold_ranks)),"folds":5,"groups":list(GROUP_FIELDS)}
    model,pre,bank=load_fold(1,device); subset=frame.loc[assigned==1].reset_index(drop=True); encoded=pre.transform(subset.iloc[:1]); batch=tensor_batch(encoded,np.array([0]),device); parameters=sum(p.numel() for p in model.parameters() if p.requires_grad)
    with torch.no_grad():
        for _ in range(100): model(batch,bank)
    if torch.cuda.is_available(): torch.cuda.synchronize()
    started=time.perf_counter()
    with torch.no_grad():
        for _ in range(10000): model(batch,bank)
    if torch.cuda.is_available(): torch.cuda.synchronize()
    latency_ms=(time.perf_counter()-started)/10000*1000; operations=float("nan")
    try:
        with torch.no_grad(),torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU],with_flops=True) as profile: model(batch,bank)
        operations=sum(event.flops for event in profile.key_averages() if event.flops)/1e9
    except Exception: pass
    histories=[json.loads((ROOT/f"outputs/logs/fold_{fold}_history.json").read_text()) for fold in range(1,6)]; efficiency={"trainable_parameters_m":parameters/1e6,"forward_operations_g":operations,"training_time_minutes":float(np.mean([x["training_seconds"] for x in histories])/60),"batch_one_latency_ms":latency_ms,"peak_gpu_memory_gb":float(np.nanmean([x["peak_gpu_memory_gb"] for x in histories])) if torch.cuda.is_available() else float("nan"),"latency_repetitions":10000,"device":device}
    (ROOT/"outputs/metrics/rank_stability.json").write_text(json.dumps(stability,indent=2),encoding="utf-8"); (ROOT/"outputs/metrics/efficiency.json").write_text(json.dumps(efficiency,indent=2),encoding="utf-8"); write_run_record(ROOT/"outputs/logs/09_interpretability_efficiency.json","interpretability_efficiency",2026,cfg,{},"completed",["outputs/metrics/permutation_importance_detail.csv","outputs/metrics/permutation_importance_summary.csv","outputs/metrics/rank_stability.json","outputs/metrics/efficiency.json"],{"device":device})

if __name__=="__main__": main()
