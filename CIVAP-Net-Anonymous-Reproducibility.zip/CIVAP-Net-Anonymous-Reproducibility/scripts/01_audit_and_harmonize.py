from _bootstrap import ROOT
from pathlib import Path
import json
from civap_net.config import load_yaml,file_sha256
from civap_net.harmonize import read_source,harmonize_development,harmonize_external,audit_frame
from civap_net.io_utils import ensure_dirs,write_json
from civap_net.logging_utils import write_run_record

def main():
    ensure_dirs(); cfg=load_yaml(ROOT/"configs/datasets.yaml")
    dev_path=ROOT/cfg["development"]["path"]; ext_path=ROOT/cfg["external"]["path"]
    if not dev_path.exists() or not ext_path.exists(): raise FileNotFoundError("Place both public source files according to configs/datasets.yaml")
    dev=harmonize_development(read_source(dev_path),cfg["development"]); ext=harmonize_external(read_source(ext_path),cfg["external"])
    dev.to_csv(ROOT/cfg["processed"]["development"],index=False); ext.to_csv(ROOT/cfg["processed"]["external"],index=False)
    audit={"development":audit_frame(dev),"external":audit_frame(ext)}; write_json(ROOT/"outputs/audit/cohort_audit.json",audit)
    write_run_record(ROOT/"outputs/logs/01_audit.json","audit_and_harmonize",2026,cfg,{str(dev_path):file_sha256(dev_path),str(ext_path):file_sha256(ext_path)},"completed",[cfg["processed"]["development"],cfg["processed"]["external"],"outputs/audit/cohort_audit.json"])

if __name__=="__main__": main()
