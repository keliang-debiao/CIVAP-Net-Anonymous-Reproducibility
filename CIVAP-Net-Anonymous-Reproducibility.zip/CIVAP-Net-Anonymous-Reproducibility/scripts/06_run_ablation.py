from _bootstrap import ROOT
from copy import deepcopy
import numpy as np
import pandas as pd
import torch
from scipy.stats import t
from sklearn.model_selection import StratifiedShuffleSplit
from civap_net.config import load_yaml
from civap_net.preprocessing import FoldPreprocessor
from civap_net.model import CIVAPNet
from civap_net.training import fit_model,predict_logits,set_seed
from civap_net.calibration import fit_temperature,apply_temperature,select_f1_threshold
from civap_net.metrics import binary_metrics
from civap_net.splits import make_inner_folds
from civap_net.io_utils import ensure_dirs
from civap_net.logging_utils import write_run_record

VARIANTS={
  "full":{},
  "without_exposure_profile_interaction":{"exposure_interaction":False},
  "without_train_label_retrieval":{"retrieval":False},
  "without_country_shrinkage_residual":{"country_residual":False},
  "without_country_risk_penalty":{"country_risk_penalty":False},
  "without_auxiliary_policy_loss":{"auxiliary_loss":False}
}

def make_model(pre,cfg):
    return CIVAPNet({k:len(v) for k,v in pre.vocab.items()},pre.country_counts,pre.vocab["country"],cfg)

def fit_once(frame,external,assigned,model_cfg,training,seed,device):
    oof=[]; external_logits=[]
    for fold in range(1,int(training["outer_folds"])+1):
        train_df=frame.loc[assigned!=fold].reset_index(drop=True); val_df=frame.loc[assigned==fold].reset_index(drop=True)
        inner=make_inner_folds(train_df,int(training["inner_folds"]),seed+fold); inner_logits=np.full(len(train_df),np.nan)
        for inner_fold in range(1,int(training["inner_folds"])+1):
            inner_train=train_df.loc[inner!=inner_fold].reset_index(drop=True); inner_val=train_df.loc[inner==inner_fold].reset_index(drop=True)
            splitter=StratifiedShuffleSplit(n_splits=1,test_size=0.12,random_state=seed+100*fold+inner_fold); fit_idx,stop_idx=next(splitter.split(inner_train,inner_train.y.astype(int)))
            pre=FoldPreprocessor().fit(inner_train); fit_data=pre.transform(inner_train.iloc[fit_idx]); stop_data=pre.transform(inner_train.iloc[stop_idx]); val_data=pre.transform(inner_val)
            inner_seed=seed+1000*fold+inner_fold; set_seed(inner_seed); model=make_model(pre,model_cfg); model,bank,_=fit_model(model,fit_data,stop_data,training,device,inner_seed)
            inner_logits[np.flatnonzero(inner==inner_fold)]=predict_logits(model,val_data,bank,device)
        temperature=fit_temperature(inner_logits,train_df.y.astype(int)); threshold=select_f1_threshold(train_df.y.astype(int),apply_temperature(inner_logits,temperature))
        splitter=StratifiedShuffleSplit(n_splits=1,test_size=0.12,random_state=seed+fold); fit_idx,stop_idx=next(splitter.split(train_df,train_df.y.astype(int)))
        pre=FoldPreprocessor().fit(train_df); fit_data=pre.transform(train_df.iloc[fit_idx]); stop_data=pre.transform(train_df.iloc[stop_idx]); val_data=pre.transform(val_df); ext_data=pre.transform(external)
        set_seed(seed+fold); model=make_model(pre,model_cfg); model,bank,_=fit_model(model,fit_data,stop_data,training,device,seed+fold)
        raw=predict_logits(model,val_data,bank,device); probability=apply_temperature(raw,temperature); external_logits.append(predict_logits(model,ext_data,bank,device))
        oof.append(pd.DataFrame({"row_id":val_df.row_id,"country":val_df.country,"y":val_data.y,"logit":raw,"probability":probability,"threshold":threshold,"fold":fold}))
    oof=pd.concat(oof,ignore_index=True); internal=binary_metrics(oof.y,oof.probability,np.nanmedian(oof.threshold))
    external_temperature=fit_temperature(oof.logit,oof.y); external_threshold=select_f1_threshold(oof.y,apply_temperature(oof.logit,external_temperature)); ext_probability=np.mean(np.vstack([apply_temperature(z,external_temperature) for z in external_logits]),axis=0); ext=binary_metrics(external.y,ext_probability,external_threshold)
    return internal,ext

def ci_of_paired_delta(full,variant):
    delta=np.asarray(full)-np.asarray(variant); mean=float(delta.mean()); half=float(t.ppf(0.975,len(delta)-1)*delta.std(ddof=1)/np.sqrt(len(delta))) if len(delta)>1 else float("nan")
    return mean,mean-half,mean+half

def main():
    ensure_dirs(); datasets=load_yaml(ROOT/"configs/datasets.yaml"); base=load_yaml(ROOT/"configs/model.yaml"); training=load_yaml(ROOT/"configs/training.yaml"); frame=pd.read_csv(ROOT/datasets["processed"]["development"]); external=pd.read_csv(ROOT/datasets["processed"]["external"]); folds=pd.read_csv(ROOT/"outputs/folds/outer_folds.csv"); fold_map=dict(zip(folds.row_id,folds.fold)); assigned=frame.row_id.map(fold_map).to_numpy(); device="cuda" if torch.cuda.is_available() else "cpu"; records=[]
    for name,changes in VARIANTS.items():
        cfg=deepcopy(base); cfg["modules"].update(changes)
        for seed in training["seeds"]:
            internal,external_result=fit_once(frame,external,assigned,cfg,training,int(seed),device); records.append({"variant":name,"seed":seed,"internal_auroc":internal["auroc"],"internal_brier":internal["brier"],"external_auroc":external_result["auroc"],"external_brier":external_result["brier"]})
    detail=pd.DataFrame(records); detail.to_csv(ROOT/"outputs/metrics/ablation_metrics_by_seed.csv",index=False); full=detail.loc[detail.variant=="full"].set_index("seed"); rows=[]
    for name,group in detail.groupby("variant",sort=False):
        aligned=group.set_index("seed").loc[full.index]; idelta,ilow,ihigh=ci_of_paired_delta(full.internal_auroc,aligned.internal_auroc); edelta,elow,ehigh=ci_of_paired_delta(full.external_auroc,aligned.external_auroc)
        rows.append({"variant":name,"internal_auroc_mean":aligned.internal_auroc.mean(),"internal_auroc_sd":aligned.internal_auroc.std(ddof=1),"internal_brier_mean":aligned.internal_brier.mean(),"internal_brier_sd":aligned.internal_brier.std(ddof=1),"external_auroc_mean":aligned.external_auroc.mean(),"external_auroc_sd":aligned.external_auroc.std(ddof=1),"internal_delta":idelta,"internal_ci_low":ilow,"internal_ci_high":ihigh,"external_delta":edelta,"external_ci_low":elow,"external_ci_high":ehigh})
    pd.DataFrame(rows).to_csv(ROOT/"outputs/metrics/ablation_summary.csv",index=False)
    write_run_record(ROOT/"outputs/logs/06_ablation.json","ablation",int(training["outer_seed"]),{"model":base,"training":training},{},"completed",["outputs/metrics/ablation_metrics_by_seed.csv","outputs/metrics/ablation_summary.csv"],{"device":device,"variants":list(VARIANTS)})

if __name__=="__main__": main()
