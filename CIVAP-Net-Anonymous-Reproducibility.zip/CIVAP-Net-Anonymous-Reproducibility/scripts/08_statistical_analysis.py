from _bootstrap import ROOT
import pandas as pd
from civap_net.config import load_yaml
from civap_net.bootstrap import paired_country_bootstrap,paired_delong_test,holm_adjust
from civap_net.logging_utils import write_run_record

def main():
    cfg=load_yaml(ROOT/"configs/statistics.yaml"); proposed=pd.read_csv(ROOT/"outputs/predictions/civap_oof.csv"); base=pd.read_csv(ROOT/"outputs/predictions/baseline_oof.csv"); rows=[]
    for model in ["logistic_regression","lightgbm","tabiclv2"]:
        subset=base.loc[base.model==model]; merged=proposed.merge(subset,on=["row_id","country","y","fold"],suffixes=("_civap","_baseline")); result=paired_country_bootstrap(merged.y,merged.probability_civap,merged.probability_baseline,merged.country,int(cfg["bootstrap_repetitions"]),int(cfg["bootstrap_seed"])); result.update({"cohort":"development","comparator":model,"delong_p":paired_delong_test(merged.y,merged.probability_civap,merged.probability_baseline)["p"]}); rows.append(result)
    adjusted=holm_adjust([r["p"] for r in rows]);
    for r,a in zip(rows,adjusted): r["holm_p"]=float(a)
    proposed_external=pd.read_csv(ROOT/"outputs/predictions/civap_external.csv"); baseline_external=pd.read_csv(ROOT/"outputs/predictions/baseline_external.csv")
    for model in ["lightgbm","tabiclv2"]:
        subset=baseline_external.loc[baseline_external.model==model]; merged=proposed_external.merge(subset,on=["row_id","country","y"],suffixes=("_civap","_baseline")); result=paired_country_bootstrap(merged.y,merged.probability_civap,merged.probability_baseline,merged.country,int(cfg["bootstrap_repetitions"]),int(cfg["bootstrap_seed"])+1); result.update({"cohort":"external","comparator":model,"holm_p":float("nan"),"delong_p":paired_delong_test(merged.y,merged.probability_civap,merged.probability_baseline)["p"]}); rows.append(result)
    pd.DataFrame(rows).to_csv(ROOT/"outputs/metrics/paired_contrasts.csv",index=False); write_run_record(ROOT/"outputs/logs/08_statistics.json","statistical_analysis",int(cfg["bootstrap_seed"]),cfg,{},"completed",["outputs/metrics/paired_contrasts.csv"])

if __name__=="__main__": main()
