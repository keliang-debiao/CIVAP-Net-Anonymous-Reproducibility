from _bootstrap import ROOT
import json
import numpy as np
import pandas as pd
import torch
from civap_net.config import load_yaml
from civap_net.preprocessing import FoldPreprocessor
from civap_net.model import CIVAPNet
from civap_net.training import predict_logits
from civap_net.calibration import apply_temperature
from civap_net.metrics import binary_metrics
from civap_net.io_utils import ensure_dirs,write_json
from civap_net.logging_utils import write_run_record

def main():
    ensure_dirs(); dcfg=load_yaml(ROOT/"configs/datasets.yaml"); external=pd.read_csv(ROOT/dcfg["processed"]["external"]); post=json.loads((ROOT/"outputs/checkpoints/external_postprocessing.json").read_text()); device="cuda" if torch.cuda.is_available() else "cpu"; probabilities=[]
    for fold in range(1,6):
        state=torch.load(ROOT/f"outputs/checkpoints/fold_{fold}.pt",map_location=device,weights_only=False); pre=FoldPreprocessor.load(ROOT/f"outputs/checkpoints/fold_{fold}_preprocessor.json"); encoded=pre.transform(external)
        model=CIVAPNet(state["vocab_sizes"],state["country_counts"],state["country_vocab"],state["model_config"]).to(device); model.load_state_dict(state["state_dict"]); bank=torch.load(ROOT/f"outputs/retrieval_banks/fold_{fold}.pt",map_location=device,weights_only=False).to(device)
        probabilities.append(apply_temperature(predict_logits(model,encoded,bank,device),post["temperature"]))
    probability=np.mean(np.vstack(probabilities),axis=0); metrics=binary_metrics(external.y,probability,post["threshold"])
    pd.DataFrame({"row_id":external.row_id,"country":external.country,"y":external.y,"probability":probability}).to_csv(ROOT/"outputs/predictions/civap_external.csv",index=False); write_json(ROOT/"outputs/metrics/civap_external_metrics.json",metrics)
    write_run_record(ROOT/"outputs/logs/05_external.json","external_validation",2026,{"postprocessing":post},{},"completed",["outputs/predictions/civap_external.csv","outputs/metrics/civap_external_metrics.json"],{"fine_tuning":False,"recalibration":False,"threshold_adjustment":False})

if __name__=="__main__": main()
