from _bootstrap import ROOT
import json
import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import StratifiedGroupKFold
from civap_net.config import load_yaml
from civap_net.preprocessing import FoldPreprocessor
from civap_net.model import CIVAPNet
from civap_net.training import predict_logits
from civap_net.calibration import apply_temperature
from civap_net.metrics import binary_metrics
from civap_net.robustness import additional_missingness,perturb_age
from civap_net.refit import cross_validated_predictions
from civap_net.io_utils import ensure_dirs
from civap_net.logging_utils import write_run_record

def load_fold(fold,device):
    state=torch.load(ROOT/f"outputs/checkpoints/fold_{fold}.pt",map_location=device,weights_only=False); pre=FoldPreprocessor.load(ROOT/f"outputs/checkpoints/fold_{fold}_preprocessor.json"); model=CIVAPNet(state["vocab_sizes"],state["country_counts"],state["country_vocab"],state["model_config"]).to(device); model.load_state_dict(state["state_dict"]); bank=torch.load(ROOT/f"outputs/retrieval_banks/fold_{fold}.pt",map_location=device,weights_only=False).to(device); model.eval(); return model,pre,bank

def perturbation_predictions(frame,assigned,condition,argument,repetition,device,post):
    parts=[]
    for fold in range(1,6):
        subset=frame.loc[assigned==fold].reset_index(drop=True); model,pre,bank=load_fold(fold,device); encoded=pre.transform(subset); seed=2026+1000*repetition+fold
        changed=additional_missingness(encoded,float(argument),seed) if condition=="additional_missingness" else perturb_age(encoded,float(argument),pre.age_std,seed)
        probability=apply_temperature(predict_logits(model,changed,bank,device),float(post.loc[fold,"temperature"])); parts.append(pd.DataFrame({"y":changed.y,"probability":probability}))
    return pd.concat(parts,ignore_index=True)

def main():
    ensure_dirs(); cfg=load_yaml(ROOT/"configs/robustness.yaml"); datasets=load_yaml(ROOT/"configs/datasets.yaml"); model_cfg=load_yaml(ROOT/"configs/model.yaml"); training=load_yaml(ROOT/"configs/training.yaml"); frame=pd.read_csv(ROOT/datasets["processed"]["development"]); folds=pd.read_csv(ROOT/"outputs/folds/outer_folds.csv"); fold_map=dict(zip(folds.row_id,folds.fold)); assigned=frame.row_id.map(fold_map).to_numpy(); post=pd.read_csv(ROOT/"outputs/metrics/civap_cv_metrics.csv").set_index("fold"); device="cuda" if torch.cuda.is_available() else "cpu"; rows=[]
    for rate in cfg["additional_missingness_rates"]:
        for repetition in range(int(cfg["missingness_repetitions"])):
            pred=perturbation_predictions(frame,assigned,"additional_missingness",rate,repetition,device,post); metric=binary_metrics(pred.y,pred.probability); rows.append({"condition":f"additional_missingness_{int(rate*100)}_percent","repetition":repetition,**metric})
    for repetition in range(int(cfg["age_noise_repetitions"])):
        pred=perturbation_predictions(frame,assigned,"age_noise",cfg["age_noise_years"],repetition,device,post); metric=binary_metrics(pred.y,pred.probability); rows.append({"condition":"age_perturbation_plus_minus_5_years","repetition":repetition,**metric})
    for repetition in range(int(cfg["reduced_training_repetitions"])):
        pred=cross_validated_predictions(frame,assigned,model_cfg,training,2026+10000+repetition,device,float(cfg["reduced_training_fraction"])); metric=binary_metrics(pred.y,pred.probability,float(np.median(pred.threshold))); rows.append({"condition":"half_training_size","repetition":repetition,**metric})
    country_split=StratifiedGroupKFold(n_splits=int(cfg["held_out_country_folds"]),shuffle=True,random_state=2026); country_assignment=np.zeros(len(frame),dtype=int)
    for fold,(_,idx) in enumerate(country_split.split(frame,frame.y.astype(int),groups=frame.country),start=1): country_assignment[idx]=fold
    country_pred=cross_validated_predictions(frame,country_assignment,model_cfg,training,22026,device); country_metric=binary_metrics(country_pred.y,country_pred.probability,float(np.median(country_pred.threshold))); rows.append({"condition":"held_out_countries","repetition":0,**country_metric})
    base=pd.read_csv(ROOT/"outputs/predictions/civap_oof.csv"); joined=base.merge(frame[["row_id","primary_slider"]],on="row_id",how="left"); kept=joined.loc[joined.primary_slider.ne(float(cfg["midpoint_sensitivity_value"]))]; midpoint_metric=binary_metrics(kept.y,kept.probability); rows.append({"condition":"exclude_slider_midpoint","repetition":0,**midpoint_metric})
    detail=pd.DataFrame(rows); detail.to_csv(ROOT/"outputs/metrics/robustness_by_repetition.csv",index=False); summary=detail.groupby("condition",as_index=False).agg(auroc=("auroc","mean"),auroc_sd=("auroc","std"),brier=("brier","mean"),brier_sd=("brier","std"),ece=("ece","mean"),ece_sd=("ece","std"),repetitions=("repetition","count")); summary.to_csv(ROOT/"outputs/metrics/robustness_summary.csv",index=False)
    write_run_record(ROOT/"outputs/logs/07_robustness.json","robustness",2026,{"robustness":cfg,"training":training},{},"completed",["outputs/metrics/robustness_by_repetition.csv","outputs/metrics/robustness_summary.csv"],{"device":device})

if __name__=="__main__": main()
