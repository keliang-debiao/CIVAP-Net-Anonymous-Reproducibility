import numpy as np
import torch
from civap_net.model import CIVAPNet

def test_model_forward_shapes():
    cfg={"dimension":64,"token_blocks":2,"attention_heads":4,"ffn_dimension":128,"interaction_rank":16,"retrieval_key_dimension":32,"country_dimension":16,"neighbors":2,"retrieval_temperature":0.15,"country_shrinkage_kappa":250,"dropout":0.1,"auxiliary_count":8,"modules":{"exposure_interaction":True,"retrieval":True,"country_residual":True,"country_risk_penalty":True,"auxiliary_loss":True}}
    vocab={"gender":5,"education":7,"exposure":4,"country":6}; country_vocab={"<UNKNOWN>":0,"<MISSING>":1,"a":2,"b":3,"c":4,"d":5}; counts={"a":120,"b":110,"c":100,"d":90}; model=CIVAPNet(vocab,counts,country_vocab,cfg)
    batch={"age":torch.randn(6),"age_observed":torch.ones(6),"gender":torch.tensor([2,3,2,4,3,2]),"education":torch.tensor([2,3,4,5,2,3]),"exposure":torch.tensor([2,3,2,3,2,3]),"country":torch.tensor([2,2,3,3,4,5]),"row_id":torch.arange(6),"y":torch.tensor([0.,1.,0.,1.,0.,1.]),"auxiliary":torch.zeros(6,8),"auxiliary_mask":torch.ones(6,8)}
    bank=model.make_bank(batch); out=model(batch,bank); assert out["logit"].shape==(6,); assert out["auxiliary"].shape==(6,8); assert out["key"].shape==(6,32)
