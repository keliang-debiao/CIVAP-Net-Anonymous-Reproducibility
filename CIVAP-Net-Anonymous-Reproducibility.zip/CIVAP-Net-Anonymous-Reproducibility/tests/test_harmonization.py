import numpy as np
import pandas as pd
from civap_net.harmonize import harmonize_development,harmonize_external

def test_development_midpoint_and_missing_id():
    frame=pd.DataFrame({"ResponseId":[1,np.nan],"Age":[30,np.nan],"Gender":[1,2],"Education.2":[3,4],"cond":[1,2],"condName":["control","message"],"country":["US","UK"],"CC_policy_1":[50,51]})
    cfg={"id":"ResponseId","age":"Age","gender":"Gender","education":"Education.2","exposure":"cond","exposure_name":"condName","country":"country","target":"CC_policy_1","auxiliary_targets":[]}
    out=harmonize_development(frame,cfg); assert out.y.tolist()==[0.0,1.0]; assert out.row_id.nunique()==2

def test_external_direction():
    frame=pd.DataFrame({"age":["18-24","65+"],"gender":["Female","Male"],"education":["College","Primary"],"treatment_climate":[0,1],"treatment_policy":[0,0],"country":["Indonesia","France"],"policy_tax_fuels":[0,2]})
    cfg={"id":"respondent_id","age":"age","gender":"gender","education":"education","treatment_climate":"treatment_climate","treatment_policy":"treatment_policy","country":"country","target":"policy_tax_fuels","pnr_value":-0.1}
    out=harmonize_external(frame,cfg); assert out.y.tolist()==[0.0,1.0]; assert out.age.tolist()==[21.0,70.0]
