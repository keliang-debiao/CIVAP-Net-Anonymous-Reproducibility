import numpy as np
from civap_net.calibration import fit_temperature,apply_temperature,select_f1_threshold
from civap_net.metrics import binary_metrics

def test_calibration_and_metrics_are_finite():
    y=np.array([0,0,0,1,1,1]); logits=np.array([-2,-1,-0.2,0.1,1,2]); t=fit_temperature(logits,y); p=apply_temperature(logits,t); g=select_f1_threshold(y,p); result=binary_metrics(y,p,g)
    assert t>0; assert 0<=g<=1; assert all(np.isfinite(v) for v in result.values())
