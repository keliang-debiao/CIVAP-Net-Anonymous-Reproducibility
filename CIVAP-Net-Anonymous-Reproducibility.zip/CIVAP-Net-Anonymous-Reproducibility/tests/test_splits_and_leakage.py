import pandas as pd
from civap_net.splits import make_outer_folds,assert_partition

def test_fold_partition_has_no_overlap():
    n=100
    frame=pd.DataFrame({"row_id":[f"r{i}" for i in range(n)],"y":[i%2 for i in range(n)],"country":[f"c{i%5}" for i in range(n)]})
    folds=make_outer_folds(frame,5,2026); assert sorted(folds.fold.value_counts().tolist())==[20,20,20,20,20]
    for k in range(1,6): assert_partition(frame.loc[folds.fold!=k,"row_id"],frame.loc[folds.fold==k,"row_id"])
